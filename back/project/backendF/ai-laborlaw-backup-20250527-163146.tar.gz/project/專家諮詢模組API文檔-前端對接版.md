# 專家諮詢模組API文檔 - 前端對接版

## 📋 基礎配置

### API基礎信息
```
API基礎URL: https://wrrfvodsaofk.sealosgzg.site/api/v1
認證方式: Bearer Token (所有API都需要認證)
響應格式: JSON
字符編碼: UTF-8
```

### 認證說明
專家諮詢模組要求所有用戶都必須登錄認證：
1. **用戶認證**: 所有用戶端API都需要用戶登錄認證
2. **管理員認證**: 管理員API需要管理員登錄認證

```javascript
// 用戶端API的Headers
Headers: {
  'Authorization': 'Bearer YOUR_JWT_TOKEN',
  'Content-Type': 'application/json'
}

// 管理員API的Headers
Headers: {
  'Authorization': 'Bearer YOUR_ADMIN_JWT_TOKEN',
  'Content-Type': 'application/json'
}
```

### 統一響應格式
所有API都遵循統一的響應格式：

**成功響應**:
```javascript
{
  "success": true,
  "message": "操作成功描述",
  "data": {
    // 具體數據內容
  }
}
```

**錯誤響應**:
```javascript
{
  "success": false,
  "message": "錯誤描述",
  "error": {
    "code": "ERROR_CODE",
    "details": "詳細錯誤信息"
  }
}
```

## 📋 數據結構說明

### 地區枚舉
台灣地區完整列表：
```javascript
const REGIONS = {
  '台北市': 'taipei',
  '新北市': 'new_taipei', 
  '桃園市': 'taoyuan',
  '台中市': 'taichung',
  '台南市': 'tainan',
  '高雄市': 'kaohsiung',
  '新竹市': 'hsinchu_city',
  '新竹縣': 'hsinchu_county',
  '彰化縣': 'changhua',
  '雲林縣': 'yunlin',
  '嘉義市': 'chiayi_city',
  '嘉義縣': 'chiayi_county',
  '屏東縣': 'pingtung',
  '宜蘭縣': 'yilan',
  '花蓮縣': 'hualien',
  '台東縣': 'taitung',
  '澎湖縣': 'penghu',
  '金門縣': 'kinmen',
  '連江縣': 'lienchiang',
  '其他': 'other'
};
```

### 簡化時間格式
```javascript
// 時間格式規則
"simplifiedTime": "HH:MM"  // 24小時制，分鐘只能是00或30
// 有效範例: "09:00", "14:30", "18:00"
// 無效範例: "14:15", "09:45"
```

## 👤 用戶端API（4個）

### 1. 提交專家諮詢申請 ⭐ 核心功能
```
POST /expert-consultations
```

**特性**: 需要用戶認證，所有用戶都必須登錄後才能提交申請

**請求參數**:
```javascript
{
  "name": "申請人姓名",                    // 必填，1-100字符
  "phone": "0912345678",                 // 必填，台灣手機號碼格式
  "email": "user@example.com",           // 可選，有效郵箱格式
  "lineId": "line_user_123",             // 可選，Line ID
  "service": "labor_contract",           // 必填，服務類型
  "details": "詳細問題描述...",            // 必填，10-2000字符
  "preferredContact": ["phone", "email"], // 必填，至少選擇一種聯繫方式
  "timeOfDay": "afternoon",              // 可選，時間偏好
  "startTime": "14:00",                  // 可選，開始時間
  "endTime": "16:00",                    // 可選，結束時間
  
  // === MVP新增字段 ===
  "region": "台北市",                    // 可選，申請人所在地區（見地區枚舉）
  "simplifiedTime": "14:30"              // 可選，偏好諮詢時間（HH:MM格式，分鐘限00或30）
}
```

**服務類型枚舉**:
- `labor_contract`: 勞動合同
- `compensation`: 薪資福利
- `termination`: 終止勞動關係
- `workplace_safety`: 工作場所安全
- `discrimination`: 歧視問題
- `other`: 其他

**聯繫方式枚舉**:
- `phone`: 電話
- `email`: 郵箱
- `line`: Line

**時間偏好枚舉**:
- `morning`: 上午
- `afternoon`: 下午
- `evening`: 晚上

**成功響應示例**:
```javascript
{
  "success": true,
  "message": "咨詢申請提交成功",
  "data": {
    "id": "67321a5b2c8a1b2c3d4e5f6g",
    "customId": "consultation_1748234567890_abc123def",
    "status": "pending",
    "region": "台北市",
    "simplifiedTime": "14:30",
    "assigned_advisor_id": null,
    "response_time": null,
    "completion_time": null,
    "completed_at": null,
    "createdAt": "2025-05-25T10:30:00.000Z"
  }
}
```

### 2. 獲取用戶申請列表
```
GET /expert-consultations/user/:userId?page=1&limit=10&status=pending
```

**認證要求**: 需要認證，只能查看自己的申請（管理員除外）

**路徑參數**:
- `userId`: 用戶ID

**查詢參數**:
- `page`: 頁碼（默認: 1）
- `limit`: 每頁數量（默認: 10，最大: 50）
- `status`: 狀態篩選（可選）

**成功響應示例**:
```javascript
{
  "success": true,
  "data": {
    "consultations": [
      {
        "_id": "67321a5b2c8a1b2c3d4e5f6g",
        "id": "consultation_1748234567890_abc123def",
        "user_id": "user123",
        "name": "張小明",
        "phone": "0912345678",
        "email": "user@example.com",
        "service_type": "labor_contract",
        "details": "想了解勞動合同相關問題...",
        "preferred_contact": ["phone", "email"],
        "status": "pending",
        "region": "台北市",
        "simplified_time": "14:30",
        "assigned_advisor_id": null,
        "response_time": null,
        "completion_time": null,
        "completed_at": null,
        "created_at": "2025-05-25T10:30:00.000Z",
        "updated_at": "2025-05-25T10:30:00.000Z"
      }
    ],
    "pagination": {
      "currentPage": 1,
      "totalPages": 3,
      "totalItems": 25,
      "hasNext": true,
      "hasPrev": false
    }
  }
}
```

### 3. 獲取申請詳情
```
GET /expert-consultations/:id
```

**認證要求**: 需要認證，只能查看自己的申請（管理員除外）

**路徑參數**:
- `id`: 申請ID

**成功響應示例**:
```javascript
{
  "success": true,
  "data": {
    "_id": "67321a5b2c8a1b2c3d4e5f6g",
    "id": "consultation_1748234567890_abc123def",
    "user_id": "user123",
    "name": "張小明",
    "phone": "0912345678",
    "email": "user@example.com",
    "line_id": "line_user_123",
    "service_type": "labor_contract",
    "details": "想了解勞動合同相關的法律問題，包括合同條款的合法性、員工權益保護等方面。",
    "preferred_contact": ["phone", "email"],
    "consultation_time": "下午 14:00-16:00",
    "status": "pending",
    "admin_notes": "",
    "processed_by": null,
    "processed_at": null,
    "region": "台北市",
    "simplified_time": "14:30",
    "assigned_advisor_id": null,
    "response_time": null,
    "completion_time": null,
    "completed_at": null,
    "created_at": "2025-05-25T10:30:00.000Z",
    "updated_at": "2025-05-25T10:30:00.000Z"
  }
}
```

### 4. 取消申請
```
PUT /expert-consultations/:id/cancel
```

**認證要求**: 需要認證，只能取消自己的申請

**路徑參數**:
- `id`: 申請ID

**請求參數**:
```javascript
{
  "reason": "取消原因（可選）"
}
```

**成功響應示例**:
```javascript
{
  "success": true,
  "message": "咨詢申請已取消",
  "data": {
    "id": "consultation_1748234567890_abc123def",
    "status": "cancelled",
    "updatedAt": "2025-05-25T11:00:00.000Z"
  }
}
```

## 👨‍💼 管理員端API（5個）

### 1. 獲取所有申請列表
```
GET /expert-consultations/admin/list?page=1&limit=10&status=&service_type=&search=
```

**認證要求**: 需要管理員權限

**查詢參數**:
- `page`: 頁碼（默認: 1）
- `limit`: 每頁數量（默認: 10，最大: 50）
- `status`: 狀態篩選（可選）
- `service_type`: 服務類型篩選（可選）
- `search`: 搜索關鍵詞，支持姓名和電話（可選）
- `startDate`: 開始日期（可選）
- `endDate`: 結束日期（可選）
- `region`: 地區篩選（可選，見地區枚舉）
- `assigned_advisor_id`: 指派顧問篩選（可選）

**成功響應示例**:
```javascript
{
  "success": true,
  "data": {
    "consultations": [
      {
        "_id": "67321a5b2c8a1b2c3d4e5f6g",
        "id": "consultation_1748234567890_abc123def",
        "user_id": "user123",
        "name": "張小明",
        "phone": "0912345678",
        "email": "user@example.com",
        "service_type": "labor_contract",
        "status": "pending",
        "created_at": "2025-05-25T10:30:00.000Z"
      }
    ],
    "pagination": {
      "currentPage": 1,
      "totalPages": 5,
      "totalItems": 48,
      "hasNext": true,
      "hasPrev": false
    },
    "statistics": {
      "total": 48,
      "pending": 15,
      "processing": 20,
      "completed": 10,
      "cancelled": 3
    }
  }
}
```

### 2. 獲取申請詳情（管理員視角）
```
GET /expert-consultations/admin/:id
```

**認證要求**: 需要管理員權限

**路徑參數**:
- `id`: 申請ID

**成功響應示例**:
```javascript
{
  "success": true,
  "data": {
    "_id": "67321a5b2c8a1b2c3d4e5f6g",
    "id": "consultation_1748234567890_abc123def",
    "user_id": "user123",
    "name": "張小明",
    "phone": "0912345678",
    "email": "user@example.com",
    "line_id": "line_user_123",
    "service_type": "labor_contract",
    "details": "詳細問題描述...",
    "preferred_contact": ["phone", "email"],
    "consultation_time": "下午 14:00-16:00",
    "status": "processing",
    "admin_notes": "已安排專家處理",
    "processed_by": "admin_user_456",
    "processed_at": "2025-05-25T11:00:00.000Z",
    "created_at": "2025-05-25T10:30:00.000Z",
    "updated_at": "2025-05-25T11:00:00.000Z"
  }
}
```

### 3. 更新申請狀態
```
PUT /expert-consultations/admin/:id
```

**認證要求**: 需要管理員權限

**路徑參數**:
- `id`: 申請ID

**請求參數**:
```javascript
{
  "status": "processing",              // 可選，新狀態
  "adminNotes": "處理備註信息",         // 可選，管理員備註
  "forceUpdate": false,               // 可選，強制更新（跳過狀態流轉規則）
  "assigned_advisor_id": "advisor_123" // 可選，指派劳资顾问ID
}
```

**狀態流轉規則**:
- `pending` → `processing` | `cancelled`
- `processing` → `completed` | `cancelled`
- `completed` → 無法變更
- `cancelled` → 無法變更

**成功響應示例**:
```javascript
{
  "success": true,
  "message": "咨詢申請已更新",
  "data": {
    "_id": "67321a5b2c8a1b2c3d4e5f6g",
    "id": "consultation_1748234567890_abc123def",
    "status": "processing",
    "admin_notes": "已安排專家處理",
    "processed_by": "admin_user_456",
    "processed_at": "2025-05-25T11:00:00.000Z",
    "updated_at": "2025-05-25T11:00:00.000Z"
  }
}
```

### 4. 刪除申請
```
DELETE /expert-consultations/admin/:id
```

**認證要求**: 需要管理員權限

**路徑參數**:
- `id`: 申請ID

**成功響應示例**:
```javascript
{
  "success": true,
  "message": "咨詢申請已刪除"
}
```

### 5. 獲取統計數據
```
GET /expert-consultations/admin/statistics?startDate=2025-05-01&endDate=2025-05-31
```

**認證要求**: 需要管理員權限

**查詢參數**:
- `startDate`: 開始日期（YYYY-MM-DD格式，可選）
- `endDate`: 結束日期（YYYY-MM-DD格式，可選）

**成功響應示例**:
```javascript
{
  "success": true,
  "data": {
    "overview": {
      "total": 150,
      "pending": 25,
      "processing": 80,
      "completed": 40,
      "cancelled": 5
    },
    "serviceTypeStats": [
      {
        "service_type": "labor_contract",
        "count": 45
      },
      {
        "service_type": "compensation",
        "count": 35
      },
      {
        "service_type": "workplace_safety",
        "count": 30
      },
      {
        "service_type": "termination",
        "count": 25
      },
      {
        "service_type": "discrimination",
        "count": 10
      },
      {
        "service_type": "other",
        "count": 5
      }
    ],
    "dailyStats": [
      {
        "date": "2025-05-25",
        "count": 8,
        "byStatus": [
          { "status": "pending", "count": 3 },
          { "status": "processing", "count": 4 },
          { "status": "completed", "count": 1 }
        ]
      }
    ]
  }
}
```

## 🚨 錯誤處理

### 常見錯誤碼
- `VALIDATION_ERROR`: 參數驗證錯誤
- `CONSULTATION_NOT_FOUND`: 申請不存在
- `FORBIDDEN`: 權限不足
- `INVALID_STATUS_TRANSITION`: 無效的狀態轉換
- `AUTH_REQUIRED`: 需要認證

### 錯誤響應示例

**驗證錯誤**:
```javascript
{
  "success": false,
  "message": "請填寫所有必填項目",
  "error": {
    "code": "VALIDATION_ERROR",
    "details": [
      "姓名為必填項",
      "請輸入有效的台灣手機號碼格式",
      "問題詳情至少需要10個字符",
      "請至少選擇一種聯繫方式"
    ]
  }
}
```

**權限錯誤**:
```javascript
{
  "success": false,
  "message": "權限不足，只能查看自己的申請",
  "error": {
    "code": "FORBIDDEN",
    "details": "Access denied"
  }
}
```

**狀態轉換錯誤**:
```javascript
{
  "success": false,
  "message": "無法將狀態從 completed 轉換為 pending",
  "error": {
    "code": "INVALID_STATUS_TRANSITION",
    "details": "Invalid status transition"
  }
}
```

## 🎯 前端對接指南

### 1. 申請提交流程
```javascript
// 游客用戶提交申請
async function submitConsultation(formData) {
  const response = await fetch('/api/v1/expert-consultations', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      name: formData.name,
      phone: formData.phone,
      email: formData.email,
      lineId: formData.lineId,
      service: formData.service,
      details: formData.details,
      preferredContact: formData.preferredContact,
      timeOfDay: formData.timeOfDay,
      startTime: formData.startTime,
      endTime: formData.endTime,
      region: formData.region,
      simplifiedTime: formData.simplifiedTime
    })
  });
  
  return await response.json();
}
```

### 2. 認證用戶查看申請
```javascript
// 獲取用戶申請列表
async function getUserConsultations(userId, page = 1, status = '') {
  const token = localStorage.getItem('auth_token');
  let url = `/api/v1/expert-consultations/user/${userId}?page=${page}`;
  if (status) url += `&status=${status}`;
  
  const response = await fetch(url, {
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    }
  });
  
  return await response.json();
}
```

### 3. 狀態顯示建議
```javascript
// 狀態中文映射
const STATUS_MAP = {
  'pending': '待處理',
  'processing': '處理中',
  'completed': '已完成',
  'cancelled': '已取消'
};

// 服務類型中文映射
const SERVICE_TYPE_MAP = {
  'labor_contract': '勞動合同',
  'compensation': '薪資福利',
  'termination': '終止勞動關係',
  'workplace_safety': '工作場所安全',
  'discrimination': '歧視問題',
  'other': '其他'
};

// 聯繫方式中文映射
const CONTACT_METHOD_MAP = {
  'phone': '電話',
  'email': '郵箱',
  'line': 'Line'
};
```

### 4. 表單驗證建議
```javascript
// 台灣手機號碼驗證
function validateTaiwanPhone(phone) {
  const phoneRegex = /^(\+886-?)?0?9\d{8}$/;
  return phoneRegex.test(phone);
}

// 郵箱驗證
function validateEmail(email) {
  if (!email) return true; // 可選字段
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

// 表單完整驗證
function validateConsultationForm(formData) {
  const errors = [];
  
  if (!formData.name?.trim()) {
    errors.push('姓名為必填項');
  }
  
  if (!validateTaiwanPhone(formData.phone)) {
    errors.push('請輸入有效的台灣手機號碼格式');
  }
  
  if (!validateEmail(formData.email)) {
    errors.push('請輸入有效的電子郵箱格式');
  }
  
  if (!formData.service) {
    errors.push('請選擇服務類型');
  }
  
  if (!formData.details?.trim() || formData.details.length < 10) {
    errors.push('問題詳情至少需要10個字符');
  }
  
  if (!formData.preferredContact?.length) {
    errors.push('請至少選擇一種聯繫方式');
  }
  
  return errors;
}
```

### 5. 地區選擇組件建議
```javascript
// 台灣地區選擇器組件
function RegionSelector({ value, onChange, placeholder = "請選擇地區" }) {
  const regions = [
    { value: '', label: placeholder },
    { value: '台北市', label: '台北市' },
    { value: '新北市', label: '新北市' },
    { value: '桃園市', label: '桃園市' },
    { value: '台中市', label: '台中市' },
    { value: '台南市', label: '台南市' },
    { value: '高雄市', label: '高雄市' },
    { value: '新竹市', label: '新竹市' },
    { value: '新竹縣', label: '新竹縣' },
    { value: '彰化縣', label: '彰化縣' },
    { value: '雲林縣', label: '雲林縣' },
    { value: '嘉義市', label: '嘉義市' },
    { value: '嘉義縣', label: '嘉義縣' },
    { value: '屏東縣', label: '屏東縣' },
    { value: '宜蘭縣', label: '宜蘭縣' },
    { value: '花蓮縣', label: '花蓮縣' },
    { value: '台東縣', label: '台東縣' },
    { value: '澎湖縣', label: '澎湖縣' },
    { value: '金門縣', label: '金門縣' },
    { value: '連江縣', label: '連江縣' },
    { value: '其他', label: '其他' }
  ];

  return (
    <select value={value} onChange={(e) => onChange(e.target.value)}>
      {regions.map(region => (
        <option key={region.value} value={region.value}>
          {region.label}
        </option>
      ))}
    </select>
  );
}
```

### 6. 簡化時間選擇器組件
```javascript
// 簡化時間選擇器（限制分鐘為00或30）
function SimplifiedTimePicker({ value, onChange, placeholder = "選擇時間" }) {
  const generateTimeOptions = () => {
    const options = [{ value: '', label: placeholder }];
    
    for (let hour = 0; hour < 24; hour++) {
      for (let minute of [0, 30]) {
        const timeValue = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
        const displayValue = `${timeValue}`;
        options.push({ value: timeValue, label: displayValue });
      }
    }
    
    return options;
  };

  return (
    <select value={value} onChange={(e) => onChange(e.target.value)}>
      {generateTimeOptions().map(option => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  );
}
```

### 7. 劳资顾问管理組件建議
```javascript
// 顾问列表組件
function LaborAdvisorList({ advisors, onEdit, onToggleStatus, onDelete, onAssign }) {
  const workloadStatusMap = {
    'light': { text: '輕鬆', class: 'status-light' },
    'normal': { text: '正常', class: 'status-normal' },
    'heavy': { text: '繁重', class: 'status-heavy' }
  };

  return (
    <div className="advisor-list">
      {advisors.map(advisor => (
        <div key={advisor.id} className="advisor-item">
          <div className="advisor-header">
            <h3>{advisor.name}</h3>
            <div className="advisor-status">
              <span className={`status ${advisor.is_active ? 'active' : 'inactive'}`}>
                {advisor.is_active ? '活躍' : '停用'}
              </span>
              <span className={`workload ${workloadStatusMap[advisor.workload_status].class}`}>
                {workloadStatusMap[advisor.workload_status].text}
              </span>
            </div>
          </div>
          
          <div className="advisor-details">
            <p><strong>地區:</strong> {advisor.region}</p>
            <p><strong>專業:</strong> {advisor.specialties.join(', ')}</p>
            <p><strong>完成案件:</strong> {advisor.total_completed}/{advisor.total_assigned}</p>
            <p><strong>平均處理時間:</strong> {advisor.avg_completion_time}小時</p>
            <p><strong>聯繫方式:</strong> {advisor.phone} | {advisor.email}</p>
          </div>
          
          <div className="advisor-actions">
            <button onClick={() => onEdit(advisor.id)}>編輯</button>
            <button 
              onClick={() => onToggleStatus(advisor.id)}
              className={advisor.is_active ? 'btn-warning' : 'btn-success'}
            >
              {advisor.is_active ? '停用' : '啟用'}
            </button>
            <button onClick={() => onAssign(advisor.id)} className="btn-primary">指派案件</button>
            <button onClick={() => onDelete(advisor.id)} className="btn-danger">刪除</button>
          </div>
        </div>
      ))}
    </div>
  );
}
```

### 8. 智能指派組件建議
```javascript
// 智能指派組件
function AdvisorAssignment({ consultationId, onAssignmentComplete }) {
  const [advisors, setAdvisors] = useState([]);
  const [selectedAdvisor, setSelectedAdvisor] = useState('');
  const [autoAssignResult, setAutoAssignResult] = useState(null);

  // 手動指派
  const handleManualAssign = async () => {
    if (!selectedAdvisor) return;
    
    try {
      const response = await fetch(`/api/v1/labor-advisors/assign/${consultationId}`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('admin_token')}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ advisor_id: selectedAdvisor })
      });
      
      const result = await response.json();
      if (result.success) {
        onAssignmentComplete(result.data);
      }
    } catch (error) {
      console.error('手動指派失敗:', error);
    }
  };

  // 自動指派
  const handleAutoAssign = async () => {
    try {
      const response = await fetch(`/api/v1/labor-advisors/auto-assign/${consultationId}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('admin_token')}`,
          'Content-Type': 'application/json'
        }
      });
      
      const result = await response.json();
      if (result.success) {
        setAutoAssignResult(result.data);
        onAssignmentComplete(result.data);
      }
    } catch (error) {
      console.error('自動指派失敗:', error);
    }
  };

  return (
    <div className="advisor-assignment">
      <h3>顧問指派</h3>
      
      <div className="assignment-section">
        <h4>手動指派</h4>
        <select 
          value={selectedAdvisor} 
          onChange={(e) => setSelectedAdvisor(e.target.value)}
        >
          <option value="">請選擇顧問</option>
          {advisors.map(advisor => (
            <option key={advisor.id} value={advisor.id}>
              {advisor.name} - {advisor.region} ({advisor.workload_status})
            </option>
          ))}
        </select>
        <button onClick={handleManualAssign} disabled={!selectedAdvisor}>
          指派顧問
        </button>
      </div>
      
      <div className="assignment-section">
        <h4>智能指派</h4>
        <button onClick={handleAutoAssign}>自動指派最佳顧問</button>
        {autoAssignResult && (
          <div className="auto-assign-result">
            <p>已指派顧問: {autoAssignResult.advisor_name}</p>
            <p>指派原因: {autoAssignResult.assignment_reason}</p>
          </div>
        )}
      </div>
    </div>
  );
}
```

### 9. 管理員功能組件建議
```javascript
// 申請列表組件（更新版）
function ConsultationList({ consultations, advisors, onStatusUpdate, onDelete, onAssignAdvisor }) {
  return (
    <div className="consultation-list">
      {consultations.map(consultation => (
        <div key={consultation.id} className="consultation-item">
          <div className="consultation-header">
            <h3>{consultation.name}</h3>
            <span className={`status ${consultation.status}`}>
              {STATUS_MAP[consultation.status]}
            </span>
            {consultation.region && (
              <span className="region-tag">{consultation.region}</span>
            )}
          </div>
          <div className="consultation-details">
            <p><strong>服務類型:</strong> {SERVICE_TYPE_MAP[consultation.service_type]}</p>
            <p><strong>聯繫電話:</strong> {consultation.phone}</p>
            <p><strong>地區:</strong> {consultation.region || '未指定'}</p>
            <p><strong>指派顧問:</strong> {consultation.assigned_advisor_name || '未指派'}</p>
            <p><strong>提交時間:</strong> {new Date(consultation.created_at).toLocaleString()}</p>
            {consultation.response_time && (
              <p><strong>響應時間:</strong> {consultation.response_time}分鐘</p>
            )}
          </div>
          <div className="consultation-actions">
            <button onClick={() => onStatusUpdate(consultation.id)}>更新狀態</button>
            <button onClick={() => onAssignAdvisor(consultation.id)}>指派顧問</button>
            <button onClick={() => onDelete(consultation.id)}>刪除</button>
          </div>
        </div>
      ))}
    </div>
  );
}
```

## 🚀 測試建議

### 測試環境
- API基礎URL: `https://wrrfvodsaofk.sealosgzg.site/api/v1`
- 測試頁面: `https://wrrfvodsaofk.sealosgzg.site/test-api.html`（專家諮詢tab）

### 測試賬號
```javascript
// 管理員賬號
{
  username: "admin",
  email: "test@ailaborlaw.com", 
  password: "Test1234"
}

// 普通管理員
{
  username: "newadmin",
  email: "newadmin@ailaborlaw.com",
  password: "Admin1234"  
}
```

### 測試流程建議
1. **游客提交測試**: 不登錄直接提交申請
2. **認證用戶測試**: 登錄後查看和管理自己的申請
3. **管理員測試**: 管理員登錄後測試所有管理功能
4. **驗證規則測試**: 提交無效數據測試驗證規則
5. **邊界條件測試**: 測試權限邊界、狀態轉換等

### 測試數據範例
```javascript
// 有效申請數據
const validConsultation = {
  "name": "測試用戶",
  "phone": "0912345678",
  "email": "test@example.com",
  "lineId": "test_line_123",
  "service": "labor_contract",
  "details": "這是一個測試申請，想了解勞動合同相關的法律問題。",
  "preferredContact": ["phone", "email"],
  "timeOfDay": "afternoon",
  "startTime": "14:00",
  "endTime": "16:00",
  "region": "台北市",
  "simplifiedTime": "14:30"
};

// 無效申請數據（用於驗證測試）
const invalidConsultation = {
  "name": "",
  "phone": "123",
  "email": "invalid-email",
  "service": "invalid_service",
  "details": "短",
  "preferredContact": [],
  "region": "invalid_region",
  "simplifiedTime": "invalid_time"
};
```

## 📞 技術支持

如在對接過程中遇到問題，請提供：
1. 具體的API端點和請求參數
2. 完整的錯誤響應
3. 瀏覽器網絡面板的請求詳情
4. 用戶角色和權限信息

---

## 🧑‍💼 劳资顾问管理API（11個）

劳资顾问管理系统提供完整的顾问管理和智能指派功能，支持基于地区、专业和工作负载的智能分配。

### 1. 获取顾问列表
```
GET /labor-advisors?page=1&limit=10&region=&specialty=&is_active=true&search=
```

**認證要求**: 需要管理員權限

**查詢參數**:
- `page`: 頁碼（默認: 1）
- `limit`: 每頁數量（默認: 10，最大: 50）
- `region`: 地區篩選（可選，見地區枚舉）
- `specialty`: 專業領域篩選（可選，見服務類型）
- `is_active`: 狀態篩選（可選，true/false）
- `search`: 搜索關鍵詞，支持姓名和電話（可選）

**成功響應示例**:
```javascript
{
  "success": true,
  "data": {
    "advisors": [
      {
        "_id": "67321a5b2c8a1b2c3d4e5f6g",
        "id": "advisor_1748234567890_abc123def",
        "name": "張顧問",
        "phone": "02-12345678",
        "email": "zhang.advisor@example.com",
        "line_id": "zhang_advisor",
        "region": "台北市",
        "specialties": ["labor_contract", "compensation"],
        "is_active": true,
        "total_assigned": 15,
        "total_completed": 12,
        "avg_completion_time": 8.5,
        "workload_status": "normal",
        "created_at": "2025-05-25T10:30:00.000Z",
        "updated_at": "2025-05-25T10:30:00.000Z"
      }
    ],
    "pagination": {
      "currentPage": 1,
      "totalPages": 3,
      "totalItems": 25,
      "hasNext": true,
      "hasPrev": false
    }
  }
}
```

### 2. 获取顾问详情
```
GET /labor-advisors/:id
```

**認證要求**: 需要管理員權限

**路徑參數**:
- `id`: 顾问ID

**成功響應示例**:
```javascript
{
  "success": true,
  "data": {
    "_id": "67321a5b2c8a1b2c3d4e5f6g",
    "id": "advisor_1748234567890_abc123def",
    "name": "張顧問",
    "phone": "02-12345678",
    "email": "zhang.advisor@example.com",
    "line_id": "zhang_advisor",
    "region": "台北市",
    "specialties": ["labor_contract", "compensation"],
    "is_active": true,
    "total_assigned": 15,
    "total_completed": 12,
    "avg_completion_time": 8.5,
    "workload_status": "normal",
    "notes": "資深勞動法專家，處理效率高",
    "created_at": "2025-05-25T10:30:00.000Z",
    "updated_at": "2025-05-25T10:30:00.000Z"
  }
}
```

### 3. 创建新顾问
```
POST /labor-advisors
```

**認證要求**: 需要管理員權限

**請求參數**:
```javascript
{
  "name": "李顧問",                      // 必填，顾问姓名
  "phone": "03-1234567",                // 必填，聯繫電話
  "email": "li.advisor@example.com",    // 必填，電子郵箱（唯一）
  "lineId": "li_advisor",               // 可選，Line ID
  "region": "桃園市",                   // 必填，服務地區
  "specialties": ["workplace_safety", "termination"], // 必填，專業領域陣列
  "notes": "專精工安法規"                // 可選，備註信息
}
```

**成功響應示例**:
```javascript
{
  "success": true,
  "message": "勞資顧問創建成功",
  "data": {
    "id": "advisor_1748234567890_def456ghi",
    "name": "李顧問",
    "email": "li.advisor@example.com",
    "region": "桃園市",
    "specialties": ["workplace_safety", "termination"],
    "is_active": true,
    "workload_status": "light",
    "created_at": "2025-05-25T12:00:00.000Z"
  }
}
```

### 4. 更新顾问信息
```
PUT /labor-advisors/:id
```

**認證要求**: 需要管理員權限

**路徑參數**:
- `id`: 顾问ID

**請求參數**:
```javascript
{
  "name": "更新後的姓名",               // 可選
  "phone": "新的電話號碼",             // 可選
  "lineId": "新的Line ID",            // 可選
  "region": "新北市",                 // 可選
  "specialties": ["labor_contract"],   // 可選，專業領域陣列
  "notes": "更新的備註信息"            // 可選
}
```

### 5. 切换顾问状态
```
PUT /labor-advisors/:id/toggle-status
```

**認證要求**: 需要管理員權限

**路徑參數**:
- `id`: 顾问ID

**成功響應示例**:
```javascript
{
  "success": true,
  "message": "顧問狀態已更新",
  "data": {
    "id": "advisor_1748234567890_abc123def",
    "name": "張顧問",
    "is_active": false,
    "updated_at": "2025-05-25T13:00:00.000Z"
  }
}
```

### 6. 删除顾问
```
DELETE /labor-advisors/:id
```

**認證要求**: 需要管理員權限

**路徑參數**:
- `id`: 顾问ID

**成功響應示例**:
```javascript
{
  "success": true,
  "message": "勞資顧問已刪除"
}
```

### 7. 搜索可用顾问
```
GET /labor-advisors/search?region=台北市&specialty=labor_contract&workload=light
```

**認證要求**: 需要管理員權限

**查詢參數**:
- `region`: 地區篩選（可選）
- `specialty`: 專業領域篩選（可選）
- `workload`: 工作負載篩選（可選：light/normal/heavy）

**成功響應示例**:
```javascript
{
  "success": true,
  "data": {
    "available_advisors": [
      {
        "id": "advisor_1748234567890_abc123def",
        "name": "張顧問", 
        "region": "台北市",
        "specialties": ["labor_contract", "compensation"],
        "workload_status": "light",
        "total_assigned": 3,
        "avg_completion_time": 6.2
      }
    ],
    "total_found": 5,
    "recommended": "advisor_1748234567890_abc123def"
  }
}
```

### 8. 获取顾问统计数据
```
GET /labor-advisors/statistics?startDate=2025-05-01&endDate=2025-05-31
```

**認證要求**: 需要管理員權限

**查詢參數**:
- `startDate`: 開始日期（YYYY-MM-DD格式，可選）
- `endDate`: 結束日期（YYYY-MM-DD格式，可選）

**成功響應示例**:
```javascript
{
  "success": true,
  "data": {
    "overview": {
      "total_advisors": 12,
      "active_advisors": 10,
      "total_assignments": 150,
      "total_completed": 135,
      "avg_response_time": 2.5
    },
    "efficiency_ranking": [
      {
        "advisor_id": "advisor_123",
        "name": "張顧問",
        "completed_cases": 25,
        "avg_completion_time": 4.2,
        "efficiency_score": 95.8
      }
    ],
    "workload_distribution": {
      "light": 4,
      "normal": 5,
      "heavy": 1
    },
    "regional_coverage": {
      "台北市": 3,
      "新北市": 2,
      "桃園市": 2,
      "台中市": 2,
      "高雄市": 1
    }
  }
}
```

### 9. 手动指派顾问
```
PUT /labor-advisors/assign/:consultationId
```

**認證要求**: 需要管理員權限

**路徑參數**:
- `consultationId`: 咨詢申請ID

**請求參數**:
```javascript
{
  "advisor_id": "advisor_1748234567890_abc123def"  // 必填，顧問ID
}
```

**成功響應示例**:
```javascript
{
  "success": true,
  "message": "顧問指派成功",
  "data": {
    "consultation_id": "consultation_1748234567890_abc123def",
    "advisor_id": "advisor_1748234567890_abc123def",
    "advisor_name": "張顧問",
    "assigned_at": "2025-05-25T14:00:00.000Z"
  }
}
```

### 10. 自动指派最佳顾问
```
POST /labor-advisors/auto-assign/:consultationId
```

**認證要求**: 需要管理員權限

**路徑參數**:
- `consultationId`: 咨詢申請ID

**成功響應示例**:
```javascript
{
  "success": true,
  "message": "已自動指派最佳顧問",
  "data": {
    "consultation_id": "consultation_1748234567890_abc123def",
    "advisor_id": "advisor_1748234567890_abc123def",
    "advisor_name": "張顧問",
    "assignment_reason": "地區匹配且工作負載最輕",
    "assigned_at": "2025-05-25T14:00:00.000Z"
  }
}
```

### 11. 获取指派历史
```
GET /labor-advisors/assignment-history/:consultationId
```

**認證要求**: 需要管理員權限

**路徑參數**:
- `consultationId`: 咨詢申請ID

**成功響應示例**:
```javascript
{
  "success": true,
  "data": {
    "consultation_id": "consultation_1748234567890_abc123def",
    "current_advisor": {
      "advisor_id": "advisor_1748234567890_abc123def",
      "advisor_name": "張顧問",
      "assigned_at": "2025-05-25T14:00:00.000Z"
    },
    "assignment_history": [
      {
        "advisor_id": "advisor_1748234567890_abc123def",
        "advisor_name": "張顧問",
        "assigned_at": "2025-05-25T14:00:00.000Z",
        "assigned_by": "admin_user_456",
        "assignment_type": "manual"
      }
    ]
  }
}
```

---

**文檔版本**: v2.0  
**最後更新**: 2025年5月27日  
**維護人員**: AI助手  
**測試狀態**: 所有API已通過真實環境測試 ✅
**相關模組**: 與聊天模組獨立運行，共享用戶認證系統 🔗  
**新增功能**: 劳资顾问管理系统（11個API）、MVP字段扩展 ⭐ 