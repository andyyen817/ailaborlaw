# AI勞基法顧問應用

## 概述
AI勞基法顧問是一個面向台灣用戶的勞動法規AI諮詢平台，旨在通過AI技術降低勞動法規諮詢門檻，提供專業易用的勞動法規咨詢服務。平台結合AI快速響應與真人專家深度解答，創新的邀請機制降低獲客成本，為用戶提供行業專業化諮詢服務。

## 目標平台
- Web (主平台)
- 響應式移動端Web
- LINE (通過二維碼接入)

## 功能模塊

### 用戶端功能
1. **用戶賬戶管理**
   - 註冊/登入系統
   - 個人資料設置
   - 賬戶安全設置

2. **AI法律諮詢**
   - 提問勞基法相關問題
   - 查看AI回答
   - 追問或提出新問題

3. **真人專家諮詢**
   - 申請專家諮詢
   - 與專家互動
   - 評價專家服務

4. **個人資料管理**
   - 修改個人信息
   - 設置偏好
   - 管理隱私設置

5. **使用記錄與統計**
   - 查看歷史諮詢記錄
   - 管理剩餘次數
   - 查看使用統計

6. **推薦獎勵系統**
   - 邀請好友註冊
   - 獲取額外諮詢次數
   - 追蹤推薦狀態

### 管理後台功能
1. **仪表盘**
   - 系統概況
   - 關鍵指標展示
   - 數據趨勢圖表

2. **用戶管理**
   - 用戶列表與搜索
   - 用戶詳情查看
   - 賬戶操作管理

3. **AI咨詢監控**
   - 實時監控AI咨詢質量
   - 會話列表與搜索
   - 問答質量評估

4. **專家諮詢管理**
   - 專家工單分配
   - 咨詢進度追蹤
   - 專家績效管理

5. **知識庫管理**
   - 法規庫管理
   - 答案模板管理
   - 內容審核與更新

6. **系統設置**
   - 系統參數配置
   - 用戶權限管理
   - AI設置調整

7. **統計報表**
   - 用戶增長統計
   - 使用行為分析
   - 轉化率分析

## 技術實現
- 前端：Vue.js (根据项目上下文), HTML, Tailwind CSS, JavaScript
- 後端：Node.js, Express.js, MongoDB (使用 Mongoose ODM), JWT (JSON Web Tokens)
- UI元素：FontAwesome圖標
- 設計原則：響應式、現代化、易用性優先

## 使用方法

### 後端服務 (Backend Service)

本項目後端使用 Node.js 和 Express.js 框架，數據庫為 MongoDB。

**環境變量配置:**
在 `backend/` 目錄下，需要一個 `.env` 文件來配置必要的環境變量，例如：
\`\`\`
NODE_ENV=development
PORT=3000 # 後端服務器運行端口
DATABASE_URL=mongodb://localhost:27017/ai_labor_law_dev # MongoDB 連接字符串
JWT_SECRET=your_very_strong_jwt_secret_key # JWT 簽名密鑰
JWT_EXPIRES_IN=1d # JWT 過期時間 (例如 1天)
JWT_REFRESH_EXPIRES_IN=7d # JWT 刷新令牌過期時間 (例如 7天)
LOG_LEVEL=info
# INITIAL_ADMIN_USERNAME=superadmin # (可選) 用於創建初始管理員
# INITIAL_ADMIN_EMAIL=superadmin@example.com
# INITIAL_ADMIN_PASSWORD=yourSuperSecurePassword
\`\`\`

**啟動後端服務:**
1. 進入後端目錄: `cd backend`
2. 安裝依賴: `npm install`
3. 啟動開發服務器: `npm run dev` (假設 `package.json` 中有 `dev` 腳本，例如使用 `nodemon`)
   或者 `npm start` (用於生產環境或普通啟動)

後端服務默認運行在 `http://localhost:3000` (或其他在 `.env` 中配置的端口)。

**主要 API 端點:**
所有 API 均以 `/api/v1` 為前綴。

*   **認證 (Auth) - `/api/v1/auth`**:
    *   `POST /register`: 用戶註冊
        *   請求體: `{ "name": "...", "email": "...", "password": "...", "profile": { ... } }`
    *   `POST /login`: 用戶登錄 (普通用戶和管理員均使用此接口)
        *   請求體: `{ "email": "...", "password": "..." }`

*   **用戶管理 (Admin - 需要管理員權限) - `/api/v1/admin/users`**:
    *   `GET /`: 獲取用戶列表 (支持篩選和分頁)
        *   查詢參數示例: `?page=1&limit=10&searchTerm=...&status=...&userType=...&sortBy=...&sortOrder=...`
    *   `POST /`: 管理員創建新用戶
        *   請求體: `{ "name": "...", "email": "...", "password": "...", "userType": "...", "status": "...", "remainingQueries": ... }`
    *   `GET /:userId`: 獲取指定用戶詳情
    *   `PUT /:userId`: 更新指定用戶信息
        *   請求體示例: `{ "remainingQueries": ..., "password": "..." (可選), "name": "...", "email": "...", "userType": "...", "status": "..." }`
    *   `PATCH /:userId/status`: 更新指定用戶狀態
        *   請求體: `{ "status": "active" | "pending" | "disabled" }`
    *   `DELETE /:userId`: 刪除指定用戶

### 開發環境信息

**前端服務器**:
- 服務器名：ailaborlawuser
- 端口：3003
- 内網調試地址：http://ailaborlawuser.ns-2rlrcc3k.svc.cluster.local:3003
- 公網調試地址：https://wmdelchfajsi.sealosgzg.site

### 管理後台
管理後台提供了完整的系統管理功能，訪問路徑為：`admin.ai-labor-advisor.tw`

主要頁面包括：
- **admin-index.html**: 管理後台入口頁面，展示所有界面導航
- **admin-dashboard.html**: 儀表盤，顯示關鍵指標和統計數據
- **admin-users.html**: 用戶管理界面，包含用戶列表和篩選功能
- **admin-ai-monitor.html**: AI咨詢監控頁面，包含監控圖表和會話列表
- **admin-expert-consults.html**: 專家咨詢管理，包含工單分配功能
- **admin-knowledge.html**: 知識庫管理，包含法規庫和答案模板管理
- **admin-settings.html**: 系統設置頁面，包含通用設置和AI設置選項
- **admin-reports.html**: 統計報表頁面，包含各類數據統計與分析

### 用戶端
用戶端提供直觀的界面供用戶使用各項功能，訪問路徑為：`www.ai-labor-advisor.tw`

主要頁面包括：
- **index.html**: 網站首頁，介紹產品功能與價值
- **login.html/register.html**: 登入和註冊頁面
- **home.html**: 用戶登入後的首頁儀表盤
- **ai-chat.html**: AI諮詢聊天界面
- **chat-history.html**: 歷史諮詢記錄頁面
- **expert-consult.html**: 專家諮詢申請與互動界面
- **profile.html**: 個人資料管理頁面

移動端版本包括：
- **mobile-home.html**: 移動端首頁
- **mobile-ai-chat.html**: 移動端AI諮詢界面
- **mobile-login.html/mobile-register.html**: 移動端登入和註冊界面
- **mobile-profile.html**: 移動端個人資料頁面
- **mobile-chat-history.html**: 移動端歷史記錄頁面

## 版本說明
當前版本：v0.3 (後端基礎搭建完成)
- 完成了所有高保真界面原型設計 (前端)
- 實現了完整的管理後台功能界面 (前端)
- **後端:**
    - 搭建了基於 Express.js 的後端服務框架 (ES 模塊)。
    - 設計並實現了 MongoDB 的 `User` 模型 (包含嵌入式 `profile`)，符合 `backend_tasks_auth_user_management.md`。
    - 實現了用戶認證功能：
        - `POST /api/v1/auth/register` (用戶註冊)
        - `POST /api/v1/auth/login` (用戶登錄，支持普通用戶和管理員)
    - 實現了管理員後台的用戶管理功能 (均需要 JWT 管理員權限驗證)：
        - `GET /api/v1/admin/users` (獲取用戶列表，支持篩選和分頁)
        - `POST /api/v1/admin/users` (管理員創建新用戶)
        - `GET /api/v1/admin/users/:userId` (獲取指定用戶詳情)
        - `PUT /api/v1/admin/users/:userId` (管理員更新用戶信息，如密碼、諮詢次數、用戶類型、狀態等)
        - `PATCH /api/v1/admin/users/:userId/status` (管理員更新用戶賬戶狀態)
        - `DELETE /api/v1/admin/users/:userId` (管理員刪除用戶)
    - 實現了 JWT 認證中間件增強功能 (任務2.4):
        - 完善了基本認證中間件 (`protect`)，包括詳細錯誤處理和安全檢查
        - 實現了基於角色的訪問控制中間件 (`isAdmin`, `isHR`, `isEmployer`, `isEmployee`)
        - 添加了多角色支持的通用中間件 (`hasRole`)，可指定多個允許的角色
        - 增加了諮詢次數檢查中間件 (`hasRemainingQueries`)
        - 實現了資源訪問控制中間件 (`isSelfOrAdmin`)，確保用戶只能訪問自己的資源
        - 添加了密碼更改時間檢查機制，提高令牌安全性
        - 實現了 JWT 生成與驗證中間件 (`protect`, `isAdmin`)。
        - 配置了基本的日誌記錄 (`logger`) 和數據庫連接 (`database.js`)。
        - 實現了用戶資料與諮詢次數管理功能 (任務3.1和3.2):
            - `GET /api/v1/users/me` (獲取當前用戶資料)
            - `PUT /api/v1/users/me` (更新當前用戶資料)
            - `GET /api/v1/users/me/queries` (獲取剩餘諮詢次數)
            - `POST /api/v1/users/me/queries/decrease` (扣減諮詢次數)
            - `POST /api/v1/admin/users/:userId/queries/increase` (管理員增加指定用戶諮詢次數)
        - (注意: 項目中原有的基於獨立 `Admin` 模型的管理員認證體系 (`admin.model.js`, `admin/auth.controller.js`, `admin/auth.routes.js`) 已轉換為 ES 模塊以保證項目運行，但其功能與新規範中基於 `User` 模型 `userType='admin'` 的管理員角色有重疊，後續可能需要整合或移除。)
        - (注意: 項目中原有的獨立 `UserProfile` 模型 (`user_profile.model.js`) 已被 `User` 模型中的嵌入式 profile 取代，此獨立文件應被移除。)

## 未來規劃
- 整合實際AI接口
- 實現用戶交互邏輯
- 開發數據分析功能
- 優化移動端體驗

## 常見問題與解決方案

### 1. 多模型認證問題 (Admin模型與User模型)

**問題描述：**
系統設計中同時存在兩個獨立的用戶認證模型：`User`模型和`Admin`模型。當使用Admin模型的登入令牌嘗試訪問僅支持User模型認證的API（如增加諮詢次數API）時，會出現"持有此令牌的用戶已不存在"(USER_NOT_FOUND)錯誤。

**原因分析：**
1. API測試頁面(`http://localhost:7070/test-api`)上使用的是Admin模型的認證接口(`/admin/auth/login`)，生成的是Admin模型的令牌
2. 而增加諮詢次數等API默認使用`protect`中間件，該中間件僅在User模型中查找與令牌關聯的用戶
3. 由於令牌是從Admin模型生成的，但API嘗試在User模型中查找對應用戶，故無法找到匹配的用戶
4. 存在模型字段不一致問題，如用戶職業信息在系統中同時使用了`occupation`和`position`字段

**解決方案：**
1. 為需要支持Admin模型認證的路由（如`/admin/users/:userId/queries/increase`）使用`protectAdmin`中間件替代原來的`protect`和`isAdmin`中間件
2. 修改控制器函數，使其能夠從`req.admin`或`req.user`中獲取管理員信息
3. 確保路由配置時不使用全局應用的中間件，而是為每個路由單獨指定所需的中間件
4. 統一系統中的字段命名，將`occupation`全部改為`position`

**具體實現：**
```javascript
// 路由配置 (backend/src/routes/admin/user.routes.js)
router.post('/:userId/queries/increase', protectAdmin, increaseQueries);

// 控制器函數 (backend/src/controllers/user.controller.js)
export const increaseQueries = async (req, res) => {
  try {
    // 從req.admin中獲取管理員信息（使用protectAdmin中間件時）
    const adminInfo = req.admin || req.user;
    
    // ...其餘函數邏輯...
  } catch (error) {
    // ...錯誤處理...
  }
};
```

### 2. 管理後台用戶管理頁面401錯誤問題

**問題描述：**
管理員（包括超級管理員和普通管理員）可以成功登入管理後台，但在訪問用戶管理頁面時，無法獲取用戶列表數據。API請求返回401錯誤（Unauthorized），並顯示錯誤訊息"您的登入已過期，請重新登入"和錯誤代碼"USER_NOT_FOUND"。

**原因分析：**
1. 管理後台登入使用的是Admin模型的API(`/api/v1/admin/auth/login`)，產生的是Admin模型令牌
2. 而用戶管理相關API（如`/api/v1/admin/users`）使用的是`protect, isAdmin`中間件組合，該中間件僅支持User模型令牌
3. 當使用Admin模型令牌訪問用戶管理API時，`protect`中間件在User模型中查找不到匹配用戶，因此返回401錯誤
4. 這是多模型認證問題的另一種表現形式，但影響了系統的核心功能

**解決方案：**
1. 修改路由配置，將所有用戶管理相關路由的中間件從`protect, isAdmin`改為`protectAdmin`：
   ```javascript
   // 修改前：
   router.get('/', protect, isAdmin, getUsers);
   
   // 修改後：
   router.get('/', protectAdmin, getUsers);
   ```

2. 調整控制器函數，使其從`req.admin`獲取管理員信息：
   ```javascript
   export const getUsers = async (req, res) => {
     try {
       // 從req.admin獲取管理員信息
       const adminInfo = req.admin;
       logger.info(`管理員 ${adminInfo.username || adminInfo.email} (ID: ${adminInfo._id}) 獲取用戶列表`);
       
       // 原有邏輯...
     } catch (error) {
       // 錯誤處理...
     }
   };
   ```

**最佳實踐：**
1. 在系統設計階段，明確認證模型和權限控制方案
2. 避免在同一系統中混合使用多種認證模型，若必須這樣做，需要設計統一的認證機制
3. 為同類API端點使用一致的認證方式
4. 實現詳細的日誌記錄，包括認證過程中的關鍵信息
5. 考慮實現通用的認證中間件，能夠同時處理多種認證模型

### 3. 超級管理員密碼認證問題

**問題描述：**
超級管理員帳號（username: admin, email: test@ailaborlaw.com）無法登入，總是返回401錯誤（用戶名或密碼錯誤），而普通管理員帳號（username: newadmin, email: newadmin@ailaborlaw.com）能夠正常登入。

**原因分析：**
1. 通過檢查數據庫記錄發現，超級管理員帳號是存在的，狀態為 active，角色為 super_admin
2. 密碼驗證測試發現，輸入的密碼"Test1234"與數據庫中存儲的密碼哈希不匹配（comparePassword方法返回false）
3. 可能是由於超級管理員帳號的密碼在某個時間點被修改過，或創建時就出現問題
4. 問題的根本原因是密碼哈希與輸入密碼不匹配

**解決方案：**
1. 使用特殊的緊急API重置超級管理員密碼（`emergencySuperAdmin` API）
2. 或使用專門的數據庫腳本直接重置超級管理員的密碼，確保密碼哈希與預期的密碼對應

**具體實現：**
```javascript
// 1. 使用緊急API重置管理員角色
curl -X POST "http://localhost:7070/api/v1/admin/auth/emergency-super-admin/test@ailaborlaw.com" \
  -H "Content-Type: application/json" \
  -d '{"secretKey":"EmergencySuperAdmin2025"}'

// 2. 使用腳本重置管理員密碼
import mongoose from 'mongoose';
import Admin from '../src/models/admin.model.js';
import bcrypt from 'bcryptjs';

async function resetAdminPassword() {
  try {
    // 連接數據庫
    await mongoose.connect(process.env.MONGODB_URI);
    
    // 生成新密碼哈希
    const salt = await bcrypt.genSalt(10);
    const password_hash = await bcrypt.hash('Test1234', salt);
    
    // 更新管理員密碼
    await Admin.updateOne(
      { email: 'test@ailaborlaw.com' },
      { $set: { password_hash: password_hash } }
    );
    
    console.log('超級管理員密碼重置成功');
  } catch (error) {
    console.error('錯誤:', error);
  }
}
```

**預防措施：**
1. 設置初始超級管理員帳號時使用`setupInitialAdmin` API，確保密碼哈希正確生成
2. 在Admin模型的pre-save鉤子中添加日誌，記錄密碼哈希生成過程
3. 開發環境中避免直接修改數據庫中的密碼哈希
4. 在密碼更改後立即測試登入功能

### 4. 前後端跨域通信問題 (CORS)

**問題描述：**
管理後台前端（運行在http://localhost:3029）無法正常連接到後端API（https://wrrfvodsaofk.sealosgzg.site/api/v1/admin/auth/login），瀏覽器控制台顯示CORS錯誤：
```
Access to fetch at 'https://wrrfvodsaofk.sealosgzg.site/api/v1/admin/auth/login' from origin 'http://localhost:3029' has been blocked by CORS policy
```

**原因分析：**
1. 瀏覽器的同源策略限制不同源（協議、域名、端口）之間的資源共享
2. 前端運行在`http://localhost:3029`，而API位於`https://wrrfvodsaofk.sealosgzg.site`
3. 後端CORS配置中未包含前端開發伺服器的源（origin）
4. 預檢請求（OPTIONS請求）失敗，導致後續的實際請求無法執行

**解決方案：**
1. 更新後端CORS配置，明確允許前端開發伺服器的源：
```javascript
// app.js
const corsOptions = {
  origin: [
    'http://userai-laborlaw.ns-2rlrcc3k.svc.cluster.local:3000',
    'http://localhost:3000',
    'http://localhost:3029',  // 添加前端開發伺服器
    'https://ailabordevbox.ns-2rlrcc3k.sealos.run',
    'https://wrrfvodsaofk.sealosgzg.site',
    process.env.CORS_ORIGIN || '*'
  ],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
};
app.use(cors(corsOptions));
```

2. 重啟後端服務，使新的CORS配置生效
3. 驗證CORS配置是否正確：
```bash
curl -I -X OPTIONS -H "Origin: http://localhost:3029" \
  https://wrrfvodsaofk.sealosgzg.site/api/v1/admin/auth/login
```
應返回以下標頭：
```
access-control-allow-origin: http://localhost:3029
access-control-allow-credentials: true
access-control-allow-methods: GET,POST,PUT,DELETE,PATCH,OPTIONS
access-control-allow-headers: Content-Type,Authorization,X-Requested-With
```

**替代解決方案：**
在前端開發環境中，可以使用代理服務器繞過CORS限制：
```javascript
// vite.config.js
export default defineConfig({
  server: {
    proxy: {
      '/api/v1': {
        target: 'https://wrrfvodsaofk.sealosgzg.site',
        changeOrigin: true,
        secure: false
      }
    }
  }
});
```

**最佳實踐：**
1. 在開發階段就考慮CORS問題，將所有可能的前端源添加到後端配置中
2. 生產環境中，限制CORS為實際需要的域名，而不是使用`*`
3. 使用環境變量配置CORS允許的域名列表，方便在不同環境中靈活設置
4. 考慮在開發環境中使用代理服務器，避免CORS問題

### 5. 前端CSS樣式導入順序問題

**問題描述：**
使用Google Chrome瀏覽器訪問前端登錄頁面（http://localhost:3029/login）和管理後台登錄頁面（http://localhost:3029/admin/login）時頁面無法正常顯示，瀏覽器控制台顯示以下警告：
```
Define @import rules at the top of the stylesheet
```
另外還有以下關於網絡慢的提示：
```
[Intervention] Slow network is detected. See https://www.chromestatus.com/feature/5636954674692096 for more details. Fallback font will be used while loading: https://fonts.gstatic.com/...
```

**原因分析：**
1. CSS文件中的`@import`規則未正確放置在樣式表頂部，違反了CSS導入規則
2. 谷歌字體加載速度較慢，造成瀏覽器使用後備字體
3. 這些問題結合起來可能導致頁面樣式渲染不正確或延遲
4. 問題主要與前端構建和CSS導入順序有關，而非後端API問題

**解決方案：**
1. 修正CSS文件，確保所有`@import`語句位於樣式表開頭：
```css
/* 正確的CSS導入順序 */
@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap');
@import url('其他外部樣式表');

/* 之後是其他CSS規則 */
body {
  font-family: 'Roboto', sans-serif;
  /* 其他樣式 */
}
```

2. 考慮使用預加載（preload）提高Google字體加載速度：
```html
<link rel="preload" href="https://fonts.gstatic.com/s/roboto/v18/KFOmCnqEu92Fr1Mu4mxK.woff2" as="font" type="font/woff2" crossorigin>
```

3. 優化字體加載策略，減少頁面渲染阻塞：
```css
/* 使用字體顯示交換策略 */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://fonts.gstatic.com/s/roboto/v18/KFOmCnqEu92Fr1Mu4mxK.woff2) format('woff2');
}
```

**預防措施：**
1. 使用CSS預處理器（如SCSS或Less）來自動管理導入順序
2. 配置前端構建工具（如Webpack或Vite）正確處理CSS導入
3. 為提高性能，考慮將Google字體本地託管而非從CDN加載
4. 使用工具檢查CSS文件中的導入順序問題
5. 在不同瀏覽器和網絡條件下測試前端應用

**最佳實踐：**
1. 遵循CSS規範，將`@import`語句置於樣式表頂部
2. 使用現代的字體加載技術如`font-display`屬性控制字體加載行為
3. 考慮使用系統字體堆棧作為備選，減少對外部字體的依賴
4. 針對慢速網絡優化前端資源加載策略
5. 使用瀏覽器開發者工具監控和優化資源加載性能

### 6. 用戶資料同步問題

**問題描述：**
用戶在前端個人資料頁面更新手機號碼和公司名稱後，這些更新未能同步到管理後台顯示。具體表現為用戶成功更新個人資料，API 請求成功且前端本地存儲已更新，但管理後台查看同一用戶詳情時，仍顯示舊資料。

**原因分析：**
1. **欄位名稱和結構不一致**：用戶模型中使用嵌入式的 `profile` 對象儲存手機號和公司名稱（`profile.phone`和`profile.company`），而前端使用的是`phoneNumber`和`companyName`
2. **更新方法差異**：一般用戶更新使用 `findByIdAndUpdate` 方法，管理員更新使用 `user.save()` 方法，這兩種方法對嵌入式文檔的處理方式不同
3. **嵌入式文檔更新問題**：在 Mongoose 中，`findByIdAndUpdate` 更新嵌入式文檔時需要使用正確的路徑表示法，目前的實現可能導致更新不完全
4. **緩存問題**：沒有適當的緩存控制頭，可能導致前端使用過時數據
5. **缺少數據同步機制**：後端沒有實現事件通知系統來同步不同API端點的數據更新

**解決方案：**
1. **修正嵌入式文檔更新方式**：
   ```javascript
   // 使用正確的點表示法更新嵌入式文檔
   const updates = {};
   if (name) updates.name = name;
   if (phone) updates['profile.phone'] = phone;
   if (company) updates['profile.company'] = company;
   
   const updatedUser = await User.findByIdAndUpdate(
     userId,
     { $set: updates },
     { new: true, runValidators: true }
   );
   ```

2. **統一更新方法**：兩個控制器使用相同的資料更新方法，推薦使用 `findById` + `save()`，確保一致的行為

3. **添加緩存控制**：
   ```javascript
   res.set('Cache-Control', 'no-cache, no-store, must-revalidate');
   res.set('Pragma', 'no-cache');
   res.set('Expires', '0');
   ```

4. **統一API響應格式**：在所有相關API中使用一致的字段命名和格式，例如統一使用 `phoneNumber` 和 `companyName`

5. **驗證方法**：在更新用戶資料後，可以手動清除前端緩存，或在瀏覽器開發者工具中禁用緩存，然後重新查詢用戶詳情
