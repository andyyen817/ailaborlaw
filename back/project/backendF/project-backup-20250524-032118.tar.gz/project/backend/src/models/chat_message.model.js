const mongoose = require('mongoose');

/**
 * 聊天消息模型
 * 根据PRD数据库设计实现
 */
const chatMessageSchema = new mongoose.Schema({
  session_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'ChatSession',
    required: true
  },
  role: {
    type: String,
    enum: ['user', 'ai'],
    required: true
  },
  content: {
    type: String,
    required: true
  },
  references: [{
    law_name: String,
    article: String,
    content: String,
    url: String
  }],
  feedback: {
    type: String,
    enum: ['helpful', 'not_helpful', null],
    default: null
  },
  created_at: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: { 
    createdAt: 'created_at', 
    updatedAt: false 
  }
});

// 索引
chatMessageSchema.index({ session_id: 1 });
chatMessageSchema.index({ role: 1 });
chatMessageSchema.index({ created_at: 1 });

// 添加反馈的方法
chatMessageSchema.methods.addFeedback = async function(feedback) {
  this.feedback = feedback;
  await this.save();
  return this;
};

// 添加法规引用的方法
chatMessageSchema.methods.addReference = async function(reference) {
  this.references.push(reference);
  await this.save();
  return this;
};

module.exports = mongoose.model('ChatMessage', chatMessageSchema); 