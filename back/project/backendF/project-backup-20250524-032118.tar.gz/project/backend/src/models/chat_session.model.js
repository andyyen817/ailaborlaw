const mongoose = require('mongoose');

/**
 * 聊天会话模型
 * 根据PRD数据库设计实现
 */
const chatSessionSchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  title: {
    type: String,
    trim: true,
    default: '新咨詢對話'
  },
  status: {
    type: String,
    enum: ['active', 'closed'],
    default: 'active'
  },
  tags: [{
    type: String,
    trim: true
  }],
  created_at: {
    type: Date,
    default: Date.now
  },
  updated_at: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: { 
    createdAt: 'created_at', 
    updatedAt: 'updated_at' 
  }
});

// 索引
chatSessionSchema.index({ user_id: 1 });
chatSessionSchema.index({ status: 1 });
chatSessionSchema.index({ created_at: 1 });
chatSessionSchema.index({ tags: 1 });

// 更新标题的方法
chatSessionSchema.methods.updateTitle = async function(newTitle) {
  this.title = newTitle;
  await this.save();
  return this;
};

// 添加标签的方法
chatSessionSchema.methods.addTag = async function(tag) {
  if (!this.tags.includes(tag)) {
    this.tags.push(tag);
    await this.save();
  }
  return this;
};

// 关闭会话的方法
chatSessionSchema.methods.closeSession = async function() {
  this.status = 'closed';
  await this.save();
  return this;
};

module.exports = mongoose.model('ChatSession', chatSessionSchema); 