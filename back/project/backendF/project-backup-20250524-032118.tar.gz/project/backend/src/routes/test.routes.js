import express from 'express';
import { 
  protect, 
  isAdmin, 
  isHR, 
  isEmployer, 
  isEmployee, 
  hasRole, 
  hasRemainingQueries,
  isSelfOrAdmin
} from '../middlewares/auth.middleware.js';

const router = express.Router();

/**
 * 測試路由
 * 基礎路徑: /api/v1/test
 * 這些路由主要用於測試認證和權限中間件
 */

// 公共路由 - 無需認證
router.get('/public', (req, res) => {
  res.status(200).json({
    success: true,
    message: '公共路由訪問成功 - 無需認證',
    data: { isAuthenticated: false }
  });
});

// 需要認證的路由
router.get('/auth', protect, (req, res) => {
  res.status(200).json({
    success: true,
    message: '認證路由訪問成功 - 需要有效令牌',
    data: {
      isAuthenticated: true,
      user: {
        id: req.user.id,
        name: req.user.name,
        email: req.user.email,
        userType: req.user.userType
      }
    }
  });
});

// 管理員角色路由
router.get('/admin', protect, isAdmin, (req, res) => {
  res.status(200).json({
    success: true,
    message: '管理員路由訪問成功 - 需要管理員權限',
    data: {
      isAuthenticated: true,
      isAdmin: true,
      user: {
        id: req.user.id,
        name: req.user.name,
        userType: req.user.userType
      }
    }
  });
});

// HR角色路由
router.get('/hr', protect, isHR, (req, res) => {
  res.status(200).json({
    success: true,
    message: 'HR路由訪問成功 - 需要HR權限',
    data: {
      isAuthenticated: true,
      isHR: true,
      user: {
        id: req.user.id,
        name: req.user.name,
        userType: req.user.userType
      }
    }
  });
});

// 雇主角色路由
router.get('/employer', protect, isEmployer, (req, res) => {
  res.status(200).json({
    success: true,
    message: '雇主路由訪問成功 - 需要雇主權限',
    data: {
      isAuthenticated: true,
      isEmployer: true,
      user: {
        id: req.user.id,
        name: req.user.name,
        userType: req.user.userType
      }
    }
  });
});

// 員工角色路由
router.get('/employee', protect, isEmployee, (req, res) => {
  res.status(200).json({
    success: true,
    message: '員工路由訪問成功 - 需要員工權限',
    data: {
      isAuthenticated: true,
      isEmployee: true,
      user: {
        id: req.user.id,
        name: req.user.name,
        userType: req.user.userType
      }
    }
  });
});

// 多角色路由 (管理員或HR)
router.get('/admin-hr', protect, hasRole(['admin', 'hr']), (req, res) => {
  res.status(200).json({
    success: true,
    message: '多角色路由訪問成功 - 需要管理員或HR權限',
    data: {
      isAuthenticated: true,
      allowedRoles: ['admin', 'hr'],
      currentRole: req.user.userType,
      user: {
        id: req.user.id,
        name: req.user.name,
        userType: req.user.userType
      }
    }
  });
});

// 檢查諮詢次數路由
router.get('/check-queries', protect, hasRemainingQueries, (req, res) => {
  res.status(200).json({
    success: true,
    message: '諮詢次數檢查通過 - 有足夠的諮詢次數',
    data: {
      isAuthenticated: true,
      remainingQueries: req.user.remainingQueries,
      user: {
        id: req.user.id,
        name: req.user.name,
        userType: req.user.userType
      }
    }
  });
});

// 測試模擬用戶資源路由 - 測試 isSelfOrAdmin 中間件
router.get('/users/:userId/profile', protect, isSelfOrAdmin(), (req, res) => {
  res.status(200).json({
    success: true,
    message: '用戶資源訪問成功 - 只能訪問自己的資源或管理員可訪問所有資源',
    data: {
      requestedUserId: req.params.userId,
      currentUserId: req.user.id,
      isAdmin: req.user.userType === 'admin',
      accessType: req.user.id === req.params.userId ? 'self' : 'admin'
    }
  });
});

// 測試令牌信息路由 - 查看當前令牌中包含的信息
router.get('/token-info', protect, (req, res) => {
  res.status(200).json({
    success: true,
    message: '令牌信息獲取成功',
    data: {
      user: req.user,
      // 不返回敏感信息，只返回安全的用戶信息
    }
  });
});

// 測試諮詢次數查詢和扣減
router.get('/queries', protect, (req, res) => {
  res.status(200).json({
    success: true,
    message: '諮詢次數測試路由 - 獲取諮詢次數信息',
    data: {
      userId: req.user.id,
      remainingQueries: req.user.remainingQueries,
      totalConsultations: req.user.totalConsultations
    }
  });
});

// 測試諮詢次數限制中間件
router.get('/queries/check', protect, hasRemainingQueries, (req, res) => {
  res.status(200).json({
    success: true,
    message: '諮詢次數檢查通過 - 您有足夠的諮詢次數',
    data: {
      userId: req.user.id,
      remainingQueries: req.user.remainingQueries,
      totalConsultations: req.user.totalConsultations
    }
  });
});

export default router; 