/**
 * 重置管理員密碼腳本
 * 這個腳本用於重置或創建超級管理員賬戶
 * 執行方式: node reset-admin-password.js
 */

import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';

// 加載環境變量
dotenv.config();

// MongoDB連接設置
const connectDatabase = async () => {
  try {
    // 使用與應用相同的連接字符串
    const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/ailabor';
    
    console.log(`嘗試連接到MongoDB: ${mongoURI}`);
    await mongoose.connect(mongoURI, {
      serverSelectionTimeoutMS: 5000,
      socketTimeoutMS: 45000,
    });
    
    console.log('MongoDB連接成功');
    return true;
  } catch (error) {
    console.error(`MongoDB連接失敗: ${error.message}`);
    return false;
  }
};

// 定義Admin模型
const adminSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true
  },
  email: {
    type: String,
    required: true,
    unique: true
  },
  password_hash: {
    type: String,
    required: true
  },
  role: {
    type: String,
    enum: ['admin', 'super_admin'],
    default: 'super_admin'
  },
  status: {
    type: String,
    enum: ['active', 'inactive'],
    default: 'active'
  },
  created_at: {
    type: Date,
    default: Date.now
  },
  updated_at: {
    type: Date,
    default: Date.now
  }
});

// 創建或使用現有的Admin模型
const Admin = mongoose.models.Admin || mongoose.model('Admin', adminSchema);

// 創建或重置管理員賬戶
const resetAdminPassword = async () => {
  try {
    // 連接數據庫
    const connected = await connectDatabase();
    if (!connected) {
      console.error('無法連接到數據庫，退出操作');
      process.exit(1);
    }

    // 要創建或更新的管理員信息
    const adminData = {
      username: 'admin',
      email: 'admin@example.com',
      password: 'Admin1234',
      role: 'admin',
      status: 'active'
    };

    // 檢查是否存在該管理員
    const existingAdmin = await Admin.findOne({ 
      $or: [
        { username: adminData.username },
        { email: adminData.email }
      ]
    });

    // 生成密碼哈希
    const salt = await bcrypt.genSalt(10);
    const password_hash = await bcrypt.hash(adminData.password, salt);

    if (existingAdmin) {
      // 更新現有管理員密碼
      existingAdmin.password_hash = password_hash;
      existingAdmin.status = 'active'; // 確保賬戶是激活的
      await existingAdmin.save();
      
      console.log(`已更新管理員密碼: ${existingAdmin.username} (${existingAdmin.email})`);
      console.log(`新密碼: ${adminData.password}`);
    } else {
      // 創建新管理員
      const newAdmin = new Admin({
        username: adminData.username,
        email: adminData.email,
        password_hash: password_hash,
        role: adminData.role,
        status: adminData.status
      });
      
      await newAdmin.save();
      
      console.log(`已創建新管理員: ${newAdmin.username} (${newAdmin.email})`);
      console.log(`密碼: ${adminData.password}`);
    }

    // 關閉數據庫連接
    await mongoose.connection.close();
    console.log('操作完成，數據庫連接已關閉');
    
  } catch (error) {
    console.error(`重置管理員密碼時發生錯誤: ${error.message}`);
    if (mongoose.connection.readyState === 1) {
      await mongoose.connection.close();
    }
    process.exit(1);
  }
};

// 執行重置操作
resetAdminPassword(); 