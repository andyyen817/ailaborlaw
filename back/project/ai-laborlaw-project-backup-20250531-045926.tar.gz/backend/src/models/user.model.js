import mongoose from 'mongoose';
import bcrypt from 'bcryptjs'; // 文档中使用 bcryptjs

// 定义 Profile Schema (嵌入式)
const userProfileSchema = new mongoose.Schema({
  industry: { type: String, trim: true }, // 行业
  position: { type: String, trim: true }, // 职位/职业
  company: { type: String, trim: true }, // 新增，公司名稱
  phone: { type: String, trim: true } // 新增，手機號碼
}, { _id: false }); // profile 作为内嵌文档, _id: false 表示不为子文档生成_id

const userSchema = new mongoose.Schema({
  name: { // 昵称 (来自文档)
    type: String,
    required: [true, '用户昵称不能为空'],
    trim: true,
  },
  email: {
    type: String,
    required: [true, '电子邮箱不能为空'],
    unique: true,
    lowercase: true,
    trim: true,
    match: [/.+\@.+\..+/, '请输入有效的电子邮箱地址'],
  },
  password: { // 存储哈希后的密码 (来自文档)
    type: String,
    required: [true, '密码不能为空'],
    minlength: [8, '密码长度不能少于8位'],
  },
  userType: { // (来自文档)
    type: String,
    enum: ['admin', 'hr', 'employer', 'employee'],
    required: [true, '用户类型不能为空'],
    default: 'employee',
  },
  status: {
    type: String,
    enum: ['active', 'pending', 'disabled', 'deleted'],
    required: [true, '账户状态不能为空'],
    default: 'active', // 默認為active，方便測試
  },
  registrationDate: { // (来自文档)
    type: Date,
    default: Date.now,
  },
  lastLogin: { // (来自文档)
    type: Date,
  },
  remainingQueries: { // 剩余咨询次数 (来自文档)
    type: Number,
    default: 10, // 新用户默认10次，管理员可修改
    min: [0, '剩余次数不能为负'],
  },
  totalConsultations: { // 累计咨询次数 (来自文档)
    type: Number,
    default: 0,
  },
  profile: userProfileSchema, // 嵌入式用户资料 (来自文档)
  
  // 新添加：邀請碼相關字段
  inviteCode: { // 用戶註冊時使用的邀請碼
    type: String,
    trim: true
  },
  
  // 記錄刪除時間
  deletedAt: {
    type: Date
  },

  // 添加：密碼更改時間，用於JWT安全驗證
  passwordChangedAt: {
    type: Date
  },

  // 可选：用于邮箱验证 (如果需要，根据文档)
  // verificationToken: { type: String },
  // verificationTokenExpires: { type: Date },

  // 可选：用于密码重置 (如果需要，根据文档)
  // resetPasswordToken: { type: String },
  // resetPasswordExpires: { type: Date },
}, {
  timestamps: true, // 自动添加 createdAt 和 updatedAt 字段
});

// 数据库索引建议 (来自文档)
// 移除重复索引 - email字段已经通过unique:true设置了索引，不需要再使用schema.index()
// userSchema.index({ email: 1 }); // 删除此行以避免重复索引警告
userSchema.index({ status: 1 });
userSchema.index({ userType: 1 });
userSchema.index({ registrationDate: -1 }); // -1 表示降序索引，通常日期查询会用到
userSchema.index({ inviteCode: 1 }); // 添加邀請碼索引，方便查詢

// 密码哈希中间件 (Mongoose pre-save hook - 来自文档)
userSchema.pre('save', async function (next) {
  // 只有在密码被修改(或新创建)时才哈希
  if (!this.isModified('password')) {
    return next();
  }
  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    
    // 更新密碼更改時間
    this.passwordChangedAt = new Date();
    
    return next();
  } catch (error) {
    // 将错误传递给 Mongoose
    const err = error instanceof Error ? error : new Error(String(error));
    return next(err);
  }
});

// 实例方法：比较密码 (来自文档)
userSchema.methods.comparePassword = async function (candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

// 实例方法：减少剩余咨询次数 (基于现有逻辑，适配文档字段)
userSchema.methods.decreaseRemainingQueries = async function() {
  if (this.remainingQueries > 0) {
    this.remainingQueries--;
    this.totalConsultations++; // 对应文档的 totalConsultations
    await this.save();
    return true;
  }
  return false;
};

// 实例方法：增加剩余咨询次数 (基于现有逻辑，适配文档字段)
userSchema.methods.increaseRemainingQueries = async function(amount) {
  if (typeof amount === 'number' && amount > 0) {
    this.remainingQueries += amount;
    await this.save();
  }
  return this.remainingQueries;
};

const User = mongoose.model('User', userSchema);

export default User;
