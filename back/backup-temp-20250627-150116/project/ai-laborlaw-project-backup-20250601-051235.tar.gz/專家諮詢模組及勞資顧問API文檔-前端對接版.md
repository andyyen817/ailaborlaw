# 專家諮詢模組API文檔 - 前端對接版 v2.1

## 📋 基礎配置

### API基礎信息
```
API基礎URL: https://wrrfvodsaofk.sealosgzg.site/api/v1
認證方式: Bearer Token
響應格式: JSON
字符編碼: UTF-8
測試頁面: https://wrrfvodsaofk.sealosgzg.site/test-api.html
```

### 認證說明
- **用戶端API**: 部分需要用戶登錄認證，部分支援游客模式
- **管理員API**: 需要管理員登錄認證

```javascript
// 用戶端API的Headers（需要認證時）
Headers: {
  'Authorization': 'Bearer YOUR_JWT_TOKEN',
  'Content-Type': 'application/json'
}

// 管理員API的Headers
Headers: {
  'Authorization': 'Bearer YOUR_ADMIN_JWT_TOKEN',
  'Content-Type': 'application/json'
}
```

### 測試賬號
```javascript
// 超級管理員
{
  username: "admin",
  email: "test@ailaborlaw.com", 
  password: "Test1234"
}

// 普通管理員
{
  username: "newadmin",
  email: "newadmin@ailaborlaw.com",
  password: "Admin1234"  
}
```

### 統一響應格式
**成功響應**:
```javascript
{
  "success": true,
  "message": "操作成功描述",
  "data": {
    // 具體數據內容
  }
}
```

**錯誤響應**:
```javascript
{
  "success": false,
  "message": "錯誤描述",
  "error": {
    "code": "ERROR_CODE",
    "details": "詳細錯誤信息"
  }
}
```

## 📋 數據結構說明

### 地區枚舉（台灣20個行政區）
```javascript
const TAIWAN_REGIONS = [
  '台北市', '新北市', '桃園市', '台中市', '台南市', '高雄市',
  '新竹市', '新竹縣', '彰化縣', '雲林縣', '嘉義市', '嘉義縣',
  '屏東縣', '宜蘭縣', '花蓮縣', '台東縣', '澎湖縣', '金門縣',
  '連江縣', '其他'
];
```

### 🎯 簡化時間格式（用戶友好版）
根據用戶反饋，簡化時間選擇體驗：
```javascript
// 時間格式：HH:MM，分鐘限制為00或30
// 範例：
"simplifiedTime": "10:00"  // 上午10點
"simplifiedTime": "14:30"  // 下午2點30分
"simplifiedTime": "20:30"  // 晚上8點30分

// 前端時間選擇器建議
const timeOptions = [];
for (let hour = 0; hour < 24; hour++) {
  timeOptions.push(`${hour.toString().padStart(2, '0')}:00`);
  timeOptions.push(`${hour.toString().padStart(2, '0')}:30`);
}
```

### 服務類型枚舉
```javascript
const SERVICE_TYPES = {
  'labor_contract': '勞動合同',
  'compensation': '薪資福利', 
  'termination': '終止勞動關係',
  'workplace_safety': '工作場所安全',
  'discrimination': '歧視問題',
  'other': '其他'
};
```

### 狀態映射
```javascript
const STATUS_MAP = {
  'pending': '待處理',
  'processing': '處理中',
  'completed': '已完成',
  'cancelled': '已取消'
};
```

## 👤 用戶端API（4個）

### 1. 提交專家諮詢申請 ⭐ 核心功能
```
POST /expert-consultations
```

**特性**: 支援游客模式，無需登錄即可提交申請

**請求參數**:
```javascript
{
  "name": "lee",                          // 必填，申請人姓名
  "phone": "0912345678",                  // 必填，聯繫電話
  "email": "lee@example.com",             // 可選，電子郵箱
  "lineId": "test_line_123",              // 可選，Line ID
  "service": "termination",               // 必填，服務類型
  "details": "我想了解終止勞動關係的法律問題，包括合同條款的合法性、員工權益保護等方面的內容。", // 必填，詳細描述
  "preferredContact": ["phone", "email"], // 必填，偏好聯繫方式
  "timeOfDay": "afternoon",               // 可選，時間段偏好
  "startTime": "14:00",                   // 可選，開始時間
  "endTime": "20:00",                     // 可選，結束時間
  
  // === 新增簡化字段 ===
  "region": "台北市",                     // 可選，申請人地區
  "simplifiedTime": "14:30"               // 可選，偏好諮詢時間（簡化版）
}
```

**實際成功響應**:
```javascript
{
  "success": true,
  "message": "✅ 申請提交成功！申請ID: consultation_1748347085740_hi57u0il0",
  "data": {
    "id": "6835a8cd758a1415438194ff",
    "customId": "consultation_1748347085740_hi57u0il0",
    "status": "pending",
    "createdAt": "2025-05-27T11:58:05.741Z"
  }
}
```

### 2. 獲取用戶申請列表
```
GET /expert-consultations/user/:userId?page=1&limit=10&status=pending
```

**認證要求**: 需要用戶認證，只能查看自己的申請

**實際成功響應**:
```javascript
{
  "success": true,
  "data": {
    "consultations": [
      {
        "_id": "6835a8cd758a1415438194ff",
        "user_id": "682d285e7bad8c7c49c6ca3c",
        "name": "lee",
        "phone": "0912345678",
        "email": "lee@example.com",
        "line_id": "test_line_123",
        "service_type": "termination",
        "details": "我想了解終止勞動關係的法律問題，包括合同條款的合法性、員工權益保護等方面的內容。",
        "preferred_contact": ["phone", "email"],
        "consultation_time": "下午 14:00-20:00",
        "status": "pending",
        "admin_notes": "",
        "processed_by": null,
        "processed_at": null,
        "id": "consultation_1748347085740_hi57u0il0",
        "created_at": "2025-05-27T11:58:05.741Z",
        "updated_at": "2025-05-27T11:58:05.741Z",
        "__v": 0
      }
    ],
    "pagination": {
      "currentPage": 1,
      "totalPages": 1,
      "totalItems": 2,
      "hasNext": false,
      "hasPrev": false
    }
  }
}
```

### 3. 獲取申請詳情
```
GET /expert-consultations/:id
```

**實際成功響應**:
```javascript
{
  "success": true,
  "data": {
    "_id": "6835a8cd758a1415438194ff",
    "user_id": "682d285e7bad8c7c49c6ca3c",
    "name": "lee",
    "phone": "0912345678",
    "email": "lee@example.com",
    "line_id": "test_line_123",
    "service_type": "termination",
    "details": "我想了解終止勞動關係的法律問題，包括合同條款的合法性、員工權益保護等方面的內容。",
    "preferred_contact": ["phone", "email"],
    "consultation_time": "下午 14:00-20:00",
    "status": "pending",
    "admin_notes": "",
    "processed_by": null,
    "processed_at": null,
    "id": "consultation_1748347085740_hi57u0il0",
    "created_at": "2025-05-27T11:58:05.741Z",
    "updated_at": "2025-05-27T11:58:05.741Z",
    "__v": 0
  }
}
```

### 4. 取消申請 ✅ 支援取消原因記錄
```
PUT /expert-consultations/:id/cancel
```

**請求參數**:
```javascript
{
  "reason": "問題解決了"  // 可選，取消原因
}
```

**實際成功響應**:
```javascript
{
  "success": true,
  "message": "咨詢申請已取消",
  "data": {
    "id": "consultation_1748347085740_hi57u0il0",
    "status": "cancelled",
    "updatedAt": "2025-05-27T12:01:40.967Z"
  }
}
```

**注意**: 取消原因會記錄在 `admin_notes` 字段中，格式為："取消原因: {用戶提供的原因}"

## 👨‍�� 管理員端API（5個）

### 1. 獲取所有申請列表
```
GET /expert-consultations/admin/list?page=1&limit=10&status=&service_type=&search=
```

**實際成功響應**:
```javascript
{
  "success": true,
  "data": {
    "consultations": [
      {
        "_id": "6835a8cd758a1415438194ff",
        "user_id": "682d285e7bad8c7c49c6ca3c",
        "name": "lee",
        "phone": "0912345678",
        "email": "lee@example.com",
        "line_id": "test_line_123",
        "service_type": "termination",
        "details": "我想了解終止勞動關係的法律問題...",
        "preferred_contact": ["phone", "email"],
        "consultation_time": "下午 14:00-20:00",
        "status": "cancelled",
        "admin_notes": "取消原因: 問題解決了",
        "processed_by": null,
        "processed_at": null,
        "id": "consultation_1748347085740_hi57u0il0",
        "created_at": "2025-05-27T11:58:05.741Z",
        "updated_at": "2025-05-27T12:01:40.967Z",
        "__v": 0
      }
    ],
    "pagination": {
      "currentPage": 1,
      "totalPages": 1,
      "totalItems": 6,
      "hasNext": false,
      "hasPrev": false
    },
    "statistics": {
      "total": 6,
      "pending": 5,
      "processing": 0,
      "completed": 0,
      "cancelled": 1
    }
  }
}
```

### 2. 更新申請狀態 ✅ 支援指派顧問
```
PUT /expert-consultations/admin/:id
```

**請求參數**:
```javascript
{
  "status": "processing",                 // 可選，新狀態
  "adminNotes": "已经联系上",             // 可選，管理員備註
  "forceUpdate": false,                   // 可選，強制更新
  "assigned_advisor_id": "advisor_123"    // 可選，指派勞資顧問ID
}
```

**實際成功響應**:
```javascript
{
  "success": true,
  "message": "咨詢申請已更新",
  "data": {
    "completed_at": null,
    "response_time": null,
    "completion_time": null,
    "_id": "6835a890758a1415438194e5",
    "user_id": "682d285e7bad8c7c49c6ca3c",
    "name": "lee",
    "phone": "0912345678",
    "email": "lee@example.com",
    "service_type": "compensation",
    "status": "processing",
    "admin_notes": "已经联系上",
    "processed_by": "682bf9758b2afb774d3c0eb8",
    "processed_at": "2025-05-27T13:53:21.197Z",
    "id": "consultation_1748347024620_ccm9k76l3",
    "assigned_advisor_id": "advisor_1748400243413_7p67s4qsm",
    "updated_at": "2025-05-28T03:19:24.712Z"
  }
}
```

### 3. 刪除申請
```
DELETE /expert-consultations/admin/:id
```

**實際成功響應**:
```javascript
{
  "success": true,
  "message": "咨詢申請已刪除"
}
```

### 4. 獲取統計數據
```
GET /expert-consultations/admin/statistics?startDate=2025-05-28&endDate=2025-05-28
```

**實際成功響應**:
```javascript
{
  "success": true,
  "data": {
    "overview": {
      "total": 0,
      "pending": 0,
      "processing": 0,
      "completed": 0,
      "cancelled": 0
    },
    "serviceTypeStats": [],
    "dailyStats": []
  }
}
```

## 🧑‍💼 劳资顾问管理API（11個）

### 1. 获取顾问列表 ✅
```
GET /labor-advisors?page=1&limit=10&region=&specialty=&is_active=true&search=
```

**實際成功響應**:
```javascript
{
  "success": true,
  "data": {
    "advisors": [
      {
        "_id": "683679c702a57a171b4405b3",
        "name": "lee",
        "phone": "0909999999",
        "email": "leer@example.com",
        "line_id": "lee123",
        "region": "桃園市",
        "specialties": ["labor_contract", "compensation", "termination"],
        "is_active": true,
        "total_assigned": 0,
        "total_completed": 0,
        "avg_completion_time": 0,
        "workload_status": "light",
        "notes": "資深勞動法專家，處理效率高",
        "id": "advisor_1748400583296_4jr1f9qaq",
        "created_at": "2025-05-28T02:49:43.296Z",
        "updated_at": "2025-05-28T02:49:43.296Z"
      }
    ],
    "pagination": {
      "currentPage": 1,
      "totalPages": 1,
      "totalItems": 2,
      "hasNext": false,
      "hasPrev": false
    }
  }
}
```

### 2. 创建新顾问 ✅
```
POST /labor-advisors
```

**請求參數**:
```javascript
{
  "name": "andy",                         // 必填，顧問姓名
  "phone": "0909088080",                  // 必填，聯繫電話
  "email": "andyr@example.com",           // 必填，電子郵箱（唯一）
  "lineId": "andy123",                    // 可選，Line ID
  "region": "高雄市",                     // 必填，服務地區
  "specialties": ["labor_contract", "compensation", "termination"], // 必填，專業領域
  "notes": "資深勞動法專家，處理效率高"    // 可選，備註
}
```

**實際成功響應**:
```javascript
{
  "success": true,
  "message": "✅ 顧問創建成功！顧問ID: advisor_1748400243413_7p67s4qsm",
  "data": {
    "name": "andy",
    "phone": "0909088080",
    "email": "andyr@example.com",
    "line_id": "andy123",
    "region": "高雄市",
    "specialties": ["labor_contract", "compensation", "termination"],
    "is_active": true,
    "total_assigned": 0,
    "total_completed": 0,
    "avg_completion_time": 0,
    "workload_status": "light",
    "notes": "資深勞動法專家，處理效率高",
    "id": "advisor_1748400243413_7p67s4qsm",
    "created_at": "2025-05-28T02:44:03.414Z",
    "updated_at": "2025-05-28T02:44:03.414Z"
  }
}
```

### 3. 获取顾问详情 ✅
```
GET /labor-advisors/:id
```

**實際成功響應**:
```javascript
{
  "success": true,
  "data": {
    "advisor": {
      "_id": "6836787302a57a171b44059f",
      "name": "andy",
      "phone": "0909088080",
      "email": "andyr@example.com",
      "line_id": "andy123",
      "region": "高雄市",
      "specialties": ["labor_contract", "compensation", "termination"],
      "is_active": true,
      "total_assigned": 0,
      "total_completed": 0,
      "avg_completion_time": 0,
      "workload_status": "light",
      "notes": "資深勞動法專家，處理效率高",
      "id": "advisor_1748400243413_7p67s4qsm",
      "created_at": "2025-05-28T02:44:03.414Z",
      "updated_at": "2025-05-28T02:44:03.414Z"
    },
    "consultationStats": [],
    "recentConsultations": []
  }
}
```

### 4. 更新顾问信息 ✅
```
PUT /labor-advisors/:id
```

### 5. 切换顾问状态 ✅
```
PUT /labor-advisors/:id/toggle-status
```

**實際成功響應**:
```javascript
{
  "success": true,
  "message": "顧問已啟用",
  "data": {
    "id": "advisor_1748400243413_7p67s4qsm",
    "name": "andyyen",
    "is_active": true
  }
}
```

### 6. 删除顾问 ✅
```
DELETE /labor-advisors/:id
```

### 7. 搜索可用顾问 ✅
```
GET /labor-advisors/search?region=桃園市&specialty=labor_contract
```

**實際成功響應**:
```javascript
{
  "success": true,
  "data": {
    "advisors": [],
    "total": 0,
    "searchCriteria": {
      "region": "桃園市",
      "specialty": "labor_contract",
      "available": "true"
    }
  }
}
```

### 8. 获取顾问统计数据 ✅
```
GET /labor-advisors/statistics
```

**實際成功響應**:
```javascript
{
  "success": true,
  "data": {
    "overview": {
      "_id": null,
      "total": 1,
      "active": 1,
      "inactive": 0,
      "light_workload": 1,
      "normal_workload": 0,
      "heavy_workload": 0,
      "total_assigned": 0,
      "total_completed": 0,
      "avg_completion_time": 0
    },
    "regionDistribution": [
      {
        "_id": "台北市",
        "count": 1,
        "avg_completion_time": 0,
        "total_completed": 0
      }
    ],
    "workloadDistribution": [
      {
        "_id": "light",
        "count": 1,
        "advisors": [
          {
            "id": "advisor_1748400243413_7p67s4qsm",
            "name": "andyyen",
            "total_assigned": 0
          }
        ]
      }
    ],
    "efficiencyRanking": [],
    "monthlyAssignments": []
  }
}
```

### 9. 手动指派顾问 ✅ 已修復
```
PUT /labor-advisors/assign/:consultationId
```

**請求參數**:
```javascript
{
  "advisorId": "advisor_1748400243413_7p67s4qsm"  // 必填，顧問ID（注意字段名）
}
```

**實際成功響應**:
```javascript
{
  "success": true,
  "message": "顧問指派成功",
  "data": {
    "consultation": {
      "id": "consultation_1748347024620_ccm9k76l3",
      "assigned_advisor_id": "advisor_1748400243413_7p67s4qsm"
    },
    "advisor": {
      "id": "advisor_1748400243413_7p67s4qsm",
      "name": "andyyen",
      "workload_status": "light"
    }
  }
}
```

### 10. 自动指派最佳顾问 ✅
```
POST /labor-advisors/auto-assign/:consultationId
```

**注意**: 需要咨詢申請包含地區信息才能自動指派

**錯誤響應（缺少地區信息）**:
```javascript
{
  "success": false,
  "message": "該案件缺少地區信息，無法自動指派",
  "error": {
    "code": "MISSING_REGION_INFO"
  }
}
```

### 11. 获取指派历史 ✅ 已修復
```
GET /labor-advisors/assignment-history/:consultationId
```

**實際成功響應**:
```javascript
{
  "success": true,
  "message": "指派歷史獲取成功",
  "data": {
    "consultationId": "consultation_1748401095682_eksn73jd5",
    "currentAdvisor": null,
    "assignmentHistory": [],
    "statusChanges": [
      {
        "status": "pending",
        "statusText": "待處理",
        "timestamp": "2025-05-28T02:58:15.683Z",
        "assignedAdvisor": null
      }
    ]
  }
}
```

## 🎯 前端開發指南

### 1. 簡化時間選擇器組件 ⭐ 用戶友好版
```javascript
// 簡化時間選擇器（30分鐘間隔）
function SimplifiedTimePicker({ value, onChange, placeholder = "選擇時間" }) {
  const generateTimeOptions = () => {
    const options = [{ value: '', label: placeholder }];
    
    for (let hour = 0; hour < 24; hour++) {
      // 每小時的00分和30分
      const hourStr = hour.toString().padStart(2, '0');
      options.push({ 
        value: `${hourStr}:00`, 
        label: `${hourStr}:00` 
      });
      options.push({ 
        value: `${hourStr}:30`, 
        label: `${hourStr}:30` 
      });
    }
    
    return options;
  };

  return (
    <select value={value} onChange={(e) => onChange(e.target.value)}>
      {generateTimeOptions().map(option => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  );
}
```

### 2. 台灣地區選擇器
```javascript
function RegionSelector({ value, onChange, placeholder = "請選擇地區" }) {
  const regions = [
    '台北市', '新北市', '桃園市', '台中市', '台南市', '高雄市',
    '新竹市', '新竹縣', '彰化縣', '雲林縣', '嘉義市', '嘉義縣',
    '屏東縣', '宜蘭縣', '花蓮縣', '台東縣', '澎湖縣', '金門縣',
    '連江縣', '其他'
  ];

  return (
    <select value={value} onChange={(e) => onChange(e.target.value)}>
      <option value="">{placeholder}</option>
      {regions.map(region => (
        <option key={region} value={region}>{region}</option>
      ))}
    </select>
  );
}
```

### 3. 申請提交表單
```javascript
async function submitConsultation(formData) {
  const response = await fetch('/api/v1/expert-consultations', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      name: formData.name,
      phone: formData.phone,
      email: formData.email,
      lineId: formData.lineId,
      service: formData.service,
      details: formData.details,
      preferredContact: formData.preferredContact,
      timeOfDay: formData.timeOfDay,
      startTime: formData.startTime,
      endTime: formData.endTime,
      region: formData.region,                    // 新增
      simplifiedTime: formData.simplifiedTime     // 新增簡化時間
    })
  });
  
  return await response.json();
}
```

### 4. 手動指派顧問（重要：正確字段名）
```javascript
async function assignAdvisorManually(consultationId, advisorId) {
  const response = await fetch(`/api/v1/labor-advisors/assign/${consultationId}`, {
    method: 'PUT',
    headers: {
      'Authorization': `Bearer ${localStorage.getItem('admin_token')}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ 
      advisorId: advisorId  // 注意：字段名是 advisorId，不是 advisor_id
    })
  });
  
  return await response.json();
}
```

### 5. 表單驗證
```javascript
function validateConsultationForm(formData) {
  const errors = [];
  
  if (!formData.name?.trim()) {
    errors.push('姓名為必填項');
  }
  
  // 台灣手機號碼驗證
  const phoneRegex = /^(\+886-?)?0?9\d{8}$/;
  if (!phoneRegex.test(formData.phone)) {
    errors.push('請輸入有效的台灣手機號碼格式');
  }
  
  if (!formData.service) {
    errors.push('請選擇服務類型');
  }
  
  if (!formData.details?.trim() || formData.details.length < 10) {
    errors.push('問題詳情至少需要10個字符');
  }
  
  if (!formData.preferredContact?.length) {
    errors.push('請至少選擇一種聯繫方式');
  }
  
  // 驗證簡化時間格式
  if (formData.simplifiedTime && !/^\d{2}:(00|30)$/.test(formData.simplifiedTime)) {
    errors.push('時間格式錯誤，分鐘只能是00或30');
  }
  
  return errors;
}
```

## 🚨 重要修復說明

### ✅ 已修復問題
1. **手動指派顧問**: 字段名已修正為 `advisorId`
2. **指派歷史**: API路由已添加並正常工作
3. **取消申請**: 支援記錄取消原因
4. **簡化時間**: 優化用戶體驗，只需選擇HH:MM格式

### 🔧 使用注意事項
1. **時間格式**: 分鐘限制為00或30，提升用戶體驗
2. **地區信息**: 自動指派需要申請包含地區信息
3. **認證**: 管理員API需要有效的管理員token
4. **字段命名**: 手動指派使用 `advisorId` 而非 `advisor_id`

## 📊 測試完成狀態

### ✅ 專家諮詢API（9個）
- 提交申請：✅ 游客模式正常
- 查看申請：✅ 認證用戶正常  
- 申請詳情：✅ 完整數據
- 取消申請：✅ 支援原因記錄
- 管理員查看：✅ 完整列表
- 狀態更新：✅ 支援指派顧問
- 刪除申請：✅ 正常
- 統計數據：✅ 完整
- 驗證規則：✅ 正常工作

### ✅ 劳资顾问管理API（11個）
- 顧問列表：✅ 分頁正常
- 創建顧問：✅ 自動生成ID
- 顧問詳情：✅ 包含統計信息
- 更新信息：✅ 部分更新
- 狀態切換：✅ 啟用/停用
- 刪除顧問：✅ 安全檢查
- 搜索顧問：✅ 多條件篩選
- 統計數據：✅ 完整報表
- 手動指派：✅ **已修復**
- 自動指派：✅ 智能匹配
- 指派歷史：✅ **已修復**

---

**文檔版本**: v2.1  
**最後更新**: 2025年5月28日  
**測試狀態**: 所有20個API測試通過 ✅  
**修復狀態**: 手動指派和指派歷史問題已解決 🔧  
**用戶體驗**: 簡化時間選擇，提升填寫效率 ⭐