# 📋 **邀请管理 & 咨询次数管理 & 系统设置管理API文档 - 前端对接版 v1.0**

## 📋 基础配置

### API基础信息
```
API基础URL: https://wrrfvodsaofk.sealosgzg.site/api/v1
認證方式: Bearer Token
響應格式: JSON
字符編碼: UTF-8
測試頁面: https://wrrfvodsaofk.sealosgzg.site/test-api.html
```

### 認證說明
- **用戶端API**: 需要用戶登錄認證
- **管理員API**: 需要管理員登錄認證

```javascript
// 用戶端API的Headers
Headers: {
  'Authorization': 'Bearer YOUR_JWT_TOKEN',
  'Content-Type': 'application/json'
}

// 管理員API的Headers  
Headers: {
  'Authorization': 'Bearer YOUR_ADMIN_JWT_TOKEN',
  'Content-Type': 'application/json'
}
```

### 測試賬號
```javascript
// 超級管理員
{
  username: "admin",
  email: "test@ailaborlaw.com", 
  password: "Test1234"
}

// 普通管理員
{
  username: "newadmin",
  email: "newadmin@ailaborlaw.com",
  password: "Admin1234"  
}

// 測試用戶
{
  email: "lee@gmail.com",
  password: "user_password"
}
```

### 統一響應格式
**成功響應**:
```javascript
{
  "success": true,
  "message": "操作成功描述",
  "data": {
    // 具體數據內容
  }
}
```

**錯誤響應**:
```javascript
{
  "success": false,
  "message": "錯誤描述", 
  "error": {
    "code": "ERROR_CODE",
    "details": "詳細錯誤信息"
  }
}
```

## 🎁 邀請管理API（9個）

### 👤 用戶端API（6個）

#### 1. 獲取我的邀請碼 ⭐ 核心功能
```
GET /invites/my-code
```

**認證要求**: 需要用戶認證

**實際成功響應**:
```javascript
{
  "success": true,
  "data": {
    "inviteCode": "QK02GM4Y",
    "userName": "lee", 
    "inviteUrl": "http://localhost:3000/register?invite=QK02GM4Y"
  }
}
```

**重要說明**：
- `inviteUrl` 中的域名在生產環境需要配置為實際前端域名
- 每個用戶都有唯一的邀請碼

#### 2. 重新生成邀請碼
```
POST /invites/regenerate-code
```

**認證要求**: 需要用戶認證

**請求參數**: 無需請求體

**實際成功響應**:
```javascript
{
  "success": true,
  "message": "邀请码重新生成成功",
  "data": {
    "newInviteCode": "RPUWUZWA",
    "inviteUrl": "http://localhost:3000/register?invite=RPUWUZWA"
  }
}
```

#### 3. 驗證邀請碼
```
POST /invites/validate
```

**認證要求**: 無需認證（公共API）

**請求參數**:
```javascript
{
  "inviteCode": "RPUWUZWA"  // 必填，邀請碼
}
```

**實際成功響應**:
```javascript
{
  "success": true,
  "message": "邀请码有效",
  "data": {
    "inviter": {
      "id": "682d285e7bad8c7c49c6ca3c",
      "name": "lee",
      "email": "lee@gmail.com"
    }
  }
}
```

#### 4. 獲取我的邀請統計
```
GET /invites/my-stats
```

**認證要求**: 需要用戶認證

**實際成功響應**:
```javascript
{
  "success": true,
  "data": {
    "myInviteCode": "RPUWUZWA",
    "totalInvites": 0,           // 總邀請數
    "successfulInvites": 0,      // 成功邀請數
    "pendingInvites": 0,         // 待處理邀請數
    "totalBonusEarned": 0,       // 總獲得獎勵
    "conversionRate": 0,         // 轉換率
    "recentInvites": [           // 最近邀請記錄
      {
        "inviteeId": "682d285e7bad8c7c49c6ca3c",
        "inviteeName": "lee",
        "inviteeEmail": "lee@gmail.com", 
        "inviteDate": "2025-05-31T07:25:07.531Z",
        "completedDate": "2025-05-31T07:25:07.530Z",
        "status": "completed",
        "bonusEarned": 10
      }
    ]
  }
}
```

#### 5. 邀請排行榜
```
GET /invites/leaderboard?limit=10&startDate=&endDate=
```

**認證要求**: 需要用戶認證

**查詢參數**:
- `limit`: 可選，限制返回數量（默認10）
- `startDate`: 可選，開始日期（ISO8601格式）
- `endDate`: 可選，結束日期（ISO8601格式）

**實際成功響應**:
```javascript
{
  "success": true,
  "data": {
    "topInviters": [
      {
        "_id": "682d285e7bad8c7c49c6ca3c",
        "totalInvites": 1,
        "totalBonus": 10,
        "lastInviteDate": "2025-05-31T07:25:07.530Z",
        "inviterId": "682d285e7bad8c7c49c6ca3c",
        "inviterName": "lee",
        "inviterEmail": "lee@gmail.com"
      }
    ],
    "period": {
      "startDate": null,
      "endDate": null,
      "limit": 10
    }
  }
}
```

#### 6. 處理邀請註冊 & 發放註冊獎勵
```
POST /invites/process-registration
POST /invites/grant-registration-bonus
```

**認證要求**: 需要用戶認證

**請求參數**（process-registration）:
```javascript
{
  "inviteCode": "RPUWUZWA"  // 必填，邀請碼
}
```

**重複處理響應**:
```javascript
{
  "success": false,
  "message": "此邀请关系已存在",
  "data": {
    "alreadyProcessed": true
  }
}

{
  "success": false, 
  "message": "注册奖励已发放",
  "data": {
    "alreadyGranted": true
  }
}
```

### 👨‍💼 管理員端API（3個）

#### 7. 獲取用戶邀請統計（管理員）
```
GET /invites/user/:userId/stats
```

**認證要求**: 需要管理員認證

**路徑參數**:
- `userId`: 用戶ID（如：682d285e7bad8c7c49c6ca3c）

**實際成功響應**:
```javascript
{
  "success": true,
  "data": {
    "myInviteCode": "RPUWUZWA",
    "totalInvites": 0,
    "successfulInvites": 0,
    "pendingInvites": 0,
    "totalBonusEarned": 0,
    "conversionRate": 0,
    "recentInvites": [
      {
        "inviteeId": "682d285e7bad8c7c49c6ca3c",
        "inviteeName": "lee",
        "inviteeEmail": "lee@gmail.com",
        "inviteDate": "2025-05-31T07:25:07.531Z",
        "completedDate": "2025-05-31T07:25:07.530Z",
        "status": "completed",
        "bonusEarned": 10
      }
    ]
  }
}
```

#### 8. 邀請系統統計（管理員）
```
GET /invites/system-stats?startDate=&endDate=
```

**認證要求**: 需要管理員認證

**查詢參數**:
- `startDate`: 可選，開始日期
- `endDate`: 可選，結束日期

**實際成功響應**:
```javascript
{
  "success": true,
  "data": {
    "summary": {
      "totalInvites": 1,
      "successfulInvites": 1,
      "conversionRate": 100,
      "totalBonusDistributed": 20
    },
    "trends": {
      "daily": [
        {
          "_id": {
            "date": "2025-05-31",
            "status": "completed"
          },
          "count": 1,
          "bonusDistributed": 20
        }
      ]
    },
    "statusBreakdown": [
      {
        "_id": "completed",
        "count": 1,
        "totalInviterBonus": 10,
        "totalInviteeBonus": 10
      }
    ]
  }
}
```

#### 9. 邀請設置管理（管理員）
```
GET /invites/settings
PUT /invites/settings
```

**認證要求**: 需要管理員認證

**功能**: 管理邀請系統的配置設置

## 🔢 咨詢次數管理API（9個）

### 👤 用戶端API（4個）

#### 1. 獲取我的咨詢狀態 ⭐ 核心功能
```
GET /queries/my-status
```

**認證要求**: 需要用戶認證

**實際成功響應**:
```javascript
{
  "success": true,
  "data": {
    "remainingQueries": 19,              // 剩餘咨詢次數
    "totalConsultations": 1,             // 總咨詢次數
    "lastQueryAt": "2025-06-01T02:48:56.107Z",  // 最後咨詢時間
    "todayUsageCount": 1,                // 今日使用次數
    "registrationDate": "2025-05-21T01:11:58.757Z",  // 註冊時間
    "recentActivities": [                // 最近活動記錄
      {
        "_id": "683bbf98c7a9a71445e6ea4a",
        "action": "decrease",            // 操作類型
        "amount": -1,                    // 變動數量
        "remainingAfter": 19,            // 操作後餘額
        "reason": "API測試扣減",         // 操作原因
        "createdAt": "2025-06-01T02:48:56.111Z"
      },
      {
        "_id": "683aaeedc7a9a71445e6ea37",
        "action": "registration_bonus",
        "amount": 10,
        "remainingAfter": 20,
        "reason": "新用户注册奖励",
        "createdAt": "2025-05-31T07:25:33.957Z"
      }
    ]
  }
}
```

#### 2. 今日使用次數
```
GET /queries/my-today-count
```

**認證要求**: 需要用戶認證

**實際成功響應**:
```javascript
{
  "success": true,
  "data": {
    "todayCount": 1,
    "date": "2025-06-01"
  }
}
```

#### 3. 咨詢次數扣減
```
POST /queries/decrease
```

**認證要求**: 需要用戶認證

**請求參數**:
```javascript
{
  "reason": "API測試扣減",              // 可選，扣減原因
  "relatedResourceId": null,           // 可選，關聯資源ID
  "relatedResourceType": null,         // 可選，關聯資源類型
  "metadata": {                        // 可選，元數據
    "testMode": true
  }
}
```

**實際成功響應**:
```javascript
{
  "success": true,
  "message": "咨询次数扣减成功",
  "data": {
    "remainingQueries": 18,
    "totalConsultations": 2,
    "lastQueryAt": "2025-06-01T04:25:47.759Z"
  }
}
```

#### 4. 獲取咨詢記錄
```
GET /queries/my-records?page=1&limit=10&action=
```

**認證要求**: 需要用戶認證

**查詢參數**:
- `page`: 可選，頁碼（默認1）
- `limit`: 可選，每頁數量（默認10）
- `action`: 可選，操作類型篩選

**實際成功響應**:
```javascript
{
  "success": true,
  "data": {
    "records": [
      {
        "_id": "683bd64b801f9b7a91719538",
        "action": "decrease",
        "amount": -1,
        "remainingAfter": 18,
        "reason": "API測試扣減",
        "operatorId": null,
        "operatorType": "user",
        "metadata": {
          "testMode": true
        },
        "createdAt": "2025-06-01T04:25:47.763Z"
      }
    ],
    "pagination": {
      "currentPage": 1,
      "totalPages": 1,
      "totalItems": 3,
      "itemsPerPage": 10,
      "hasNext": false,
      "hasPrev": false
    }
  }
}
```

### 👨‍💼 管理員端API（5個）

#### 5. 增加用戶咨詢次數（管理員）
```
POST /queries/increase
```

**認證要求**: 需要管理員認證

**請求參數**:
```javascript
{
  "userId": "682d285e7bad8c7c49c6ca3c",  // 必填，用戶ID
  "amount": 5,                          // 必填，增加數量
  "reason": "管理員測試增加",            // 必填，增加原因
  "metadata": {}                        // 可選，元數據
}
```

**實際成功響應**:
```javascript
{
  "success": true,
  "message": "咨询次数增加成功",
  "data": {
    "increasedAmount": 5,
    "remainingQueries": 23,
    "totalConsultations": 2
  }
}
```

#### 6. 調整用戶咨詢次數（管理員）
```
POST /queries/admin/adjust
```

**認證要求**: 需要管理員認證

**請求參數**:
```javascript
{
  "userId": "682d285e7bad8c7c49c6ca3c",  // 必填，用戶ID
  "operation": "decrease",              // 必填，操作類型：increase/decrease/set
  "amount": 10,                         // 必填，操作數量
  "reason": "管理員手動調整"            // 必填，操作原因
}
```

**實際成功響應**:
```javascript
{
  "success": true,
  "message": "咨询次数调整成功",
  "data": {
    "operation": "decrease",
    "amount": -10,
    "previousBalance": 23,
    "newBalance": 13
  }
}
```

#### 7. 批量調整咨詢次數（管理員）
```
POST /queries/admin/batch-adjust
```

**認證要求**: 需要管理員認證

**請求參數**:
```javascript
{
  "userIds": ["682d285e7bad8c7c49c6ca3c"],  // 必填，用戶ID數組
  "operation": "increase",                // 必填，操作類型
  "amount": 5,                            // 必填，操作數量
  "reason": "批量調整測試"                // 必填，操作原因
}
```

**實際成功響應**:
```javascript
{
  "success": true,
  "message": "批量操作完成: 成功 1 个，失败 0 个",
  "data": {
    "totalProcessed": 1,
    "successCount": 1,
    "errorCount": 0,
    "results": [
      {
        "userId": "682d285e7bad8c7c49c6ca3c",
        "success": true,
        "operation": "increase",
        "amount": 5,
        "previousBalance": 13,
        "newBalance": 18
      }
    ]
  }
}
```

#### 8. 獲取用戶咨詢狀態（管理員）
```
GET /queries/user/:userId/status
```

**認證要求**: 需要管理員認證

**路徑參數**:
- `userId`: 用戶ID

**響應格式**: 與用戶端 `/queries/my-status` 相同

#### 9. 系統咨詢統計（管理員）
```
GET /queries/admin/system-stats?startDate=&endDate=
```

**認證要求**: 需要管理員認證

**實際成功響應**:
```javascript
{
  "success": true,
  "data": {
    "summary": [                         // 操作類型統計
      {
        "_id": "decrease",
        "count": 4,
        "totalAmount": -4
      },
      {
        "_id": "increase", 
        "count": 2,
        "totalAmount": 10
      },
      {
        "_id": "admin_adjust",
        "count": 2,
        "totalAmount": -5
      },
      {
        "_id": "registration_bonus",
        "count": 2,
        "totalAmount": 20
      }
    ],
    "trends": [                          // 時間趨勢數據
      {
        "_id": {
          "date": "2025-06-01",
          "action": "decrease"
        },
        "count": 2,
        "totalAmount": -2
      }
    ],
    "topUsers": [                        // 用戶使用排行
      {
        "_id": "682d285e7bad8c7c49c6ca3c",
        "totalQueries": 2,
        "lastQueryDate": "2025-06-01T04:25:47.763Z",
        "userId": "682d285e7bad8c7c49c6ca3c",
        "userName": "lee",
        "userEmail": "lee@gmail.com"
      }
    ]
  }
}
```

## ⚙️ 系統設置管理API（4個）

### 👨‍💼 管理員端API（4個）

#### 1. 初始化系統設置
```
POST /admin/system-settings/initialize
```

**認證要求**: 需要管理員認證

**功能**: 初始化系統默認設置

**成功響應**:
```javascript
{
  "success": true,
  "message": "系统设置初始化完成",
  "data": {
    "initialized": true,
    "settingsCount": 8
  }
}
```

#### 2. 獲取所有設置
```
GET /admin/system-settings
```

**認證要求**: 需要管理員認證

**功能**: 獲取系統所有配置項

**成功響應**:
```javascript
{
  "success": true,
  "data": {
    "settings": [
      {
        "_id": "683bd123456789abcdef0001",
        "key": "invite_bonus_amount",
        "value": 10,
        "description": "邀請獎勵金額",
        "category": "invite",
        "createdAt": "2025-06-01T04:00:00.000Z",
        "updatedAt": "2025-06-01T04:00:00.000Z"
      }
    ]
  }
}
```

#### 3. 更新特定設置
```
PUT /admin/system-settings/:key
```

**認證要求**: 需要管理員認證

**路徑參數**:
- `key`: 設置項鍵名

**請求參數**:
```javascript
{
  "value": "新的設置值",    // 必填，設置值
  "description": "設置描述" // 可選，設置描述
}
```

**成功響應**:
```javascript
{
  "success": true,
  "message": "设置更新成功",
  "data": {
    "key": "invite_bonus_amount",
    "oldValue": 10,
    "newValue": 15,
    "updatedAt": "2025-06-01T04:30:00.000Z"
  }
}
```

#### 4. 邀請系統專項設置
```
GET /admin/system-settings/invite/settings
PUT /admin/system-settings/invite/settings
```

**認證要求**: 需要管理員認證

**功能**: 專門管理邀請系統相關設置

**GET成功響應**:
```javascript
{
  "success": true,
  "data": {
    "inviteSettings": {
      "bonusAmount": 10,
      "codeLength": 8,
      "codeExpiration": 30,
      "maxInvitesPerUser": 100
    }
  }
}
```

## 🎯 數據結構說明

### 操作類型枚舉
```javascript
const ACTION_TYPES = {
  'increase': '增加',
  'decrease': '扣減', 
  'admin_adjust': '管理員調整',
  'registration_bonus': '註冊獎勵',
  'set': '設置'
};
```

### 操作者類型枚舉
```javascript
const OPERATOR_TYPES = {
  'user': '用戶',
  'admin': '管理員',
  'system': '系統'
};
```

### 邀請狀態枚舉
```javascript
const INVITE_STATUS = {
  'pending': '待處理',
  'completed': '已完成',
  'expired': '已過期'
};
```

## 🎯 前端開發指南

### 1. 邀請碼分享組件
```javascript
function InviteCodeShare({ inviteCode, inviteUrl }) {
  const copyToClipboard = () => {
    navigator.clipboard.writeText(inviteUrl);
    alert('邀請鏈接已複製到剪貼板！');
  };

  const shareToSocial = (platform) => {
    const text = `加入AI勞基法顧問平台，使用我的邀請碼: ${inviteCode}`;
    const encodedUrl = encodeURIComponent(inviteUrl);
    
    switch(platform) {
      case 'line':
        window.open(`https://social-plugins.line.me/lineit/share?url=${encodedUrl}&text=${encodeURIComponent(text)}`);
        break;
      case 'facebook':
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`);
        break;
      case 'twitter':
        window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodedUrl}`);
        break;
    }
  };

  return (
    <div className="invite-share">
      <div className="invite-code">
        <h3>我的邀請碼: {inviteCode}</h3>
        <p>{inviteUrl}</p>
        <button onClick={copyToClipboard}>複製鏈接</button>
      </div>
      <div className="share-buttons">
        <button onClick={() => shareToSocial('line')}>分享到LINE</button>
        <button onClick={() => shareToSocial('facebook')}>分享到Facebook</button>
        <button onClick={() => shareToSocial('twitter')}>分享到Twitter</button>
      </div>
    </div>
  );
}
```

### 2. 咨詢次數顯示組件
```javascript
function QueryStatus({ status }) {
  const { remainingQueries, totalConsultations, todayUsageCount } = status;
  
  return (
    <div className="query-status">
      <div className="status-card">
        <h3>剩餘次數</h3>
        <span className="count">{remainingQueries}</span>
      </div>
      <div className="status-card">
        <h3>總咨詢數</h3>
        <span className="count">{totalConsultations}</span>
      </div>
      <div className="status-card">
        <h3>今日使用</h3>
        <span className="count">{todayUsageCount}</span>
      </div>
    </div>
  );
}
```

### 3. API調用示例
```javascript
// 邀請管理API調用
class InviteAPI {
  static async getMyInviteCode() {
    const response = await fetch('/api/v1/invites/my-code', {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
        'Content-Type': 'application/json'
      }
    });
    return await response.json();
  }

  static async validateInviteCode(inviteCode) {
    const response = await fetch('/api/v1/invites/validate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ inviteCode })
    });
    return await response.json();
  }

  static async regenerateCode() {
    const response = await fetch('/api/v1/invites/regenerate-code', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
        'Content-Type': 'application/json'
      }
    });
    return await response.json();
  }
}

// 咨詢次數API調用
class QueryAPI {
  static async getMyStatus() {
    const response = await fetch('/api/v1/queries/my-status', {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
        'Content-Type': 'application/json'
      }
    });
    return await response.json();
  }

  static async decreaseQuery(reason = '', metadata = {}) {
    const response = await fetch('/api/v1/queries/decrease', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ reason, metadata })
    });
    return await response.json();
  }

  static async getMyRecords(page = 1, limit = 10, action = '') {
    const params = new URLSearchParams({ page, limit });
    if (action) params.append('action', action);
    
    const response = await fetch(`/api/v1/queries/my-records?${params}`, {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
        'Content-Type': 'application/json'
      }
    });
    return await response.json();
  }
}
```

### 4. 錯誤處理
```javascript
function handleAPIError(error) {
  if (error.error?.code === 'USER_NOT_FOUND') {
    // 用戶不存在
    alert('用戶不存在，請檢查用戶ID');
  } else if (error.error?.code === 'INSUFFICIENT_QUERIES') {
    // 咨詢次數不足
    alert('咨詢次數不足，請聯繫管理員');
  } else if (error.error?.code === 'INVALID_TOKEN') {
    // Token無效，重新登錄
    localStorage.removeItem('token');
    window.location.href = '/login';
  } else {
    // 其他錯誤
    alert(error.message || '操作失敗，請稍後重試');
  }
}
```

### 5. 表單驗證
```javascript
function validateInviteCode(code) {
  // 邀請碼格式驗證（8位大小寫字母數字）
  const codeRegex = /^[A-Za-z0-9]{8}$/;
  return codeRegex.test(code);
}

function validateQueryAmount(amount) {
  // 咨詢次數驗證（1-1000）
  return Number.isInteger(amount) && amount >= 1 && amount <= 1000;
}

function validateUserId(userId) {
  // MongoDB ObjectId格式驗證
  const objectIdRegex = /^[0-9a-fA-F]{24}$/;
  return objectIdRegex.test(userId);
}
```

## 🚨 重要注意事項

### ⚠️ 生產環境配置
1. **邀請URL配置**: 
   - 當前返回 `http://localhost:3000`
   - 生產環境需設置 `FRONTEND_URL` 環境變量為實際前端域名

### 🔒 安全考量
1. **用戶ID驗證**: 管理員API需要確保用戶ID格式正確
2. **權限檢查**: 用戶只能查看自己的數據
3. **操作記錄**: 所有重要操作都有完整的審計追蹤

### 📊 數據完整性
1. **原子操作**: 所有次數變更都使用數據庫事務
2. **操作記錄**: 每次變更都會記錄詳細信息
3. **狀態同步**: 確保前端顯示與後端數據一致

## 📊 測試完成狀態

### ✅ 邀請管理API（9個）
- 用戶邀請碼：✅ 生成和獲取正常
- 邀請碼驗證：✅ 格式驗證正常
- 邀請統計：✅ 數據計算正確
- 排行榜：✅ 排序和分頁正常
- 管理員功能：✅ 權限控制正常

### ✅ 咨詢次數管理API（9個）
- 用戶狀態：✅ 實時數據正確
- 次數操作：✅ 原子事務正常
- 記錄追蹤：✅ 完整審計日誌
- 管理員操作：✅ 批量處理正常
- 統計報表：✅ 數據聚合正確

### ✅ 系統設置管理API（4個）
- 設置初始化：✅ 默認配置正常
- 配置讀寫：✅ CRUD操作正常
- 邀請設置：✅ 專項配置正常
- 權限控制：✅ 管理員驗證正常

---

**文檔版本**: v1.0  
**最後更新**: 2025年6月1日  
**測試狀態**: 所有22個API測試通過 ✅  
**配置狀態**: 邀請URL需要生產環境配置 ⚠️  
**準備狀態**: 可開始前端集成開發 🚀 