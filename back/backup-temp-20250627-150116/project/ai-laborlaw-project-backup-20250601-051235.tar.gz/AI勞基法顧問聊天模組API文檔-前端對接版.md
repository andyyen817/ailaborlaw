# AI勞基法顧問聊天模組API文檔 - 前端對接版

## 📋 基礎配置

### API基礎信息
```
API基礎URL: https://wrrfvodsaofk.sealosgzg.site/api/v1
認證方式: Bearer Token
響應格式: JSON
字符編碼: UTF-8
```

### 認證說明
所有API請求需在Header中包含認證令牌：
```javascript
Headers: {
  'Authorization': 'Bearer YOUR_JWT_TOKEN',
  'Content-Type': 'application/json'
}
```

### 統一響應格式
所有API都遵循統一的響應格式：

**成功響應**:
```javascript
{
  "success": true,
  "message": "操作成功描述",
  "data": {
    // 具體數據內容
  }
}
```

**錯誤響應**:
```javascript
{
  "success": false,
  "message": "錯誤描述",
  "error": {
    "code": "ERROR_CODE",
    "details": "詳細錯誤信息"
  }
}
```

## 👤 用戶端API（7個）

### 1. 會話管理類（5個API）

#### 1.1 創建新會話
```
POST /chat/sessions
```

**請求參數**:
```javascript
{
  "title": "會話標題" // 可選，若不提供系統會根據首條消息自動生成
}
```

**成功響應示例**:
```javascript
{
  "success": true,
  "message": "会话创建成功",
  "data": {
    "sessionId": "sess_1748143200087_gcnr0wiea",
    "title": "我的員工偷錢",
    "status": "active",
    "messageCount": 0,
    "createdAt": "2025-05-25T03:20:00.091Z",
    "lastMessageAt": "2025-05-25T03:20:00.087Z"
  }
}
```

#### 1.2 獲取會話列表
```
GET /chat/sessions?page=1&limit=20&search=關鍵詞
```

**查詢參數**:
- `page`: 頁碼（默認: 1）
- `limit`: 每頁數量（默認: 20，最大: 50）
- `search`: 搜索關鍵詞（可選）

**成功響應示例**:
```javascript
{
  "success": true,
  "data": {
    "sessions": [
      {
        "_id": "6831e29625c316ce61a0a802",
        "title": "请问加班费的计算方式？",
        "status": "active",
        "messageCount": 1,
        "duration": 0,
        "sessionId": "sess_1748099734677_h852ykw05",
        "lastMessageAt": "2025-05-24T15:15:48.843Z",
        "createdAt": "2025-05-24T15:15:34.680Z",
        "id": "6831e29625c316ce61a0a802"
      }
    ],
    "pagination": {
      "currentPage": 1,
      "totalPages": 1,
      "totalSessions": 4,
      "hasNextPage": false,
      "hasPrevPage": false
    }
  }
}
```

#### 1.3 獲取會話詳情
```
GET /chat/sessions/:sessionId
```

**成功響應示例**:
```javascript
{
  "success": true,
  "data": {
    "session": {
      "sessionId": "sess_1748143984909_7lo4bbgrq",
      "title": "我的員工每天上班偷溜出去接私活",
      "status": "active",
      "messageCount": 1,
      "createdAt": "2025-05-25T03:33:04.909Z",
      "lastMessageAt": "2025-05-25T03:33:25.405Z",
      "duration": 0
    },
    "messages": [
      {
        "metadata": {
          "references": []
        },
        "_id": "68328f7a65e69be9ccc63e8d",
        "role": "user",
        "content": "我的員工每天上班偷溜出去接私活",
        "status": "sent",
        "feedback": null,
        "messageId": "msg_1748143994236_f49nuxkt0",
        "createdAt": "2025-05-25T03:33:14.237Z",
        "id": "68328f7a65e69be9ccc63e8d"
      }
    ]
  }
}
```

#### 1.4 更新會話標題
```
PUT /chat/sessions/:sessionId
```

**請求參數**:
```javascript
{
  "title": "新的會話標題"
}
```

**成功響應示例**:
```javascript
{
  "success": true,
  "message": "会话标题更新成功",
  "data": {
    "sessionId": "sess_1748143200087_gcnr0wiea",
    "title": "我的員工每天上班都偷溜出去"
  }
}
```

#### 1.5 刪除會話
```
DELETE /chat/sessions/:sessionId
```

**成功響應示例**:
```javascript
{
  "success": true,
  "message": "会话已删除",
  "data": {
    "deletedSessionId": "sess_1748143200087_gcnr0wiea",
    "deletedMessages": 2
  }
}
```

### 2. 消息處理類（2個API）

#### 2.1 發送消息並獲取AI回復 ⭐ 核心功能
```
POST /chat/sessions/:sessionId/messages
```

**請求參數**:
```javascript
{
  "content": "請問加班費的計算方式？",
  "messageType": "question" // question | follow-up | clarification
}
```

**成功響應示例**:
```javascript
{
  "success": true,
  "message": "消息发送成功",
  "data": {
    "userMessage": {
      "messageId": "msg_1748143246287_hgjzc7pj2",
      "role": "user",
      "content": "我的員工偷錢",
      "status": "sent",
      "createdAt": "2025-05-25T03:20:46.288Z"
    },
    "aiResponse": {
      "messageId": "msg_1748143259744_787dko5cp",
      "role": "ai",
      "content": "情境解說：如果你的員工在工作期間有**偷竊公司財物**（例如偷錢）的行為...",
      "status": "sent",
      "processingTime": 13437,
      "references": [
        {
          "law": "勞動基準法",
          "article": "第12條",
          "content": "",
          "url": "https://law.moj.gov.tw/LawClass/LawAll.aspx?pcode=N0030001",
          "_id": "68328c9b65e69be9ccc63e5f",
          "id": "68328c9b65e69be9ccc63e5f"
        }
      ],
      "createdAt": "2025-05-25T03:20:59.747Z"
    },
    "remainingQueries": 0,
    "sessionUpdated": {
      "messageCount": 2,
      "lastMessageAt": "2025-05-25T03:20:59.747Z"
    }
  }
}
```

**重要字段說明**:
- `processingTime`: AI處理時間（毫秒）
- `references`: 法條引用，包含法律名稱、條文、內容和相關連結
- `remainingQueries`: 用戶剩餘諮詢次數
- `sessionUpdated`: 會話更新信息

#### 2.2 提交用戶反饋
```
POST /chat/sessions/:sessionId/messages/:messageId/feedback
```

**請求參數**:
```javascript
{
  "feedback": "helpful" // helpful | not_helpful
}
```

**成功響應示例**:
```javascript
{
  "success": true,
  "message": "反馈提交成功",
  "data": {
    "message": {
      "messageId": "msg_1748143259744_787dko5cp",
      "feedback": "not_helpful"
    }
  }
}
```

## 👨‍💼 管理員端API（4個）

### 1. 會話監控類（2個API）

#### 1.1 獲取所有用戶會話
```
GET /admin/chat/sessions?page=1&limit=20&status=active&userId=&search=
```

**查詢參數**:
- `page`: 頁碼（默認: 1）
- `limit`: 每頁數量（默認: 20，最大: 50）
- `status`: 會話狀態（active | completed | abandoned）
- `userId`: 特定用戶ID篩選
- `search`: 搜索關鍵詞

**成功響應示例**:
```javascript
{
  "success": true,
  "data": {
    "sessions": [
      {
        "sessionId": "sess_1748143984909_7lo4bbgrq",
        "userId": "683092143791ac67cb92e208",
        "userName": "leo1",
        "userEmail": "leo@gmail.com",
        "userPosition": "管理者",
        "title": "我的員工每天上班偷溜出去接私活",
        "messageCount": 1,
        "status": "active",
        "duration": 0,
        "categories": [],
        "createdAt": "2025-05-25T03:33:04.909Z",
        "lastMessageAt": "2025-05-25T03:33:25.405Z"
      }
    ],
    "pagination": {
      "currentPage": 1,
      "totalPages": 1,
      "totalSessions": 5,
      "hasNextPage": false,
      "hasPrevPage": false
    },
    "stats": {
      "totalSessions": 5,
      "activeSessions": 5,
      "completedSessions": 0,
      "abandonedSessions": 0,
      "avgMessagesPerSession": 1.2
    }
  }
}
```

#### 1.2 獲取會話詳情（管理員視角）
```
GET /admin/chat/sessions/:sessionId/messages
```

**成功響應示例**:
```javascript
{
  "success": true,
  "data": {
    "session": {
      "sessionId": "sess_1748143984909_7lo4bbgrq",
      "title": "我的員工每天上班偷溜出去接私活",
      "status": "active",
      "messageCount": 1,
      "duration": 0,
      "createdAt": "2025-05-25T03:33:04.909Z",
      "lastMessageAt": "2025-05-25T03:33:25.405Z",
      "user": {
        "id": "683092143791ac67cb92e208",
        "name": "leo1",
        "email": "leo@gmail.com",
        "position": "管理者"
      }
    },
    "messages": [
      {
        "metadata": {
          "messageType": "question",
          "references": [],
          "containsSensitiveInfo": false
        },
        "_id": "68328f7a65e69be9ccc63e8d",
        "role": "user",
        "content": "我的員工每天上班偷溜出去接私活",
        "status": "sent",
        "feedback": null,
        "messageId": "msg_1748143994236_f49nuxkt0",
        "editHistory": [],
        "createdAt": "2025-05-25T03:33:14.237Z",
        "id": "68328f7a65e69be9ccc63e8d"
      }
    ]
  }
}
```

### 2. 統計數據類（2個API）

#### 2.1 獲取聊天統計數據
```
GET /admin/chat/stats?startDate=2025-05-25&endDate=2025-05-25
```

**查詢參數**:
- `startDate`: 開始日期（YYYY-MM-DD格式）
- `endDate`: 結束日期（YYYY-MM-DD格式）

**成功響應示例**:
```javascript
{
  "success": true,
  "data": {
    "overview": {
      "totalSessions": 4,
      "totalMessages": 10,
      "totalUsers": 1,
      "avgSessionDuration": 0,
      "avgResponseTime": 7.14
    },
    "dailyStats": [
      {
        "date": "2025-05-24",
        "sessions": 4,
        "messages": 5,
        "avgResponseTime": 7.14
      }
    ],
    "feedbackStats": {
      "helpful": 0,
      "not_helpful": 0,
      "satisfaction": 0
    },
    "topCategories": [],
    "n8nService": {
      "totalCalls": 0,
      "successCalls": 0,
      "failedCalls": 0,
      "avgResponseTime": 0,
      "successRate": "0%",
      "avgResponseTimeFormatted": "0ms"
    },
    "dateRange": {
      "startDate": "2025-05-24T00:00:00.000Z",
      "endDate": "2025-05-24T23:59:59.999Z"
    }
  }
}
```

#### 2.2 導出聊天記錄
```
POST /admin/chat/export
```

**請求參數**:
```javascript
{
  "startDate": "2025-05-25",
  "endDate": "2025-05-25",
  "format": "excel", // excel | csv
  "includeUserInfo": true,
  "sessionIds": ["sess_id1", "sess_id2"] // 可選，特定會話導出
}
```

**成功響應**:
- **Content-Type**: `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`
- **Content-Disposition**: `attachment; filename="聊天记录导出_2025-05-25T07-56-11.xlsx"`
- **響應體**: 二進制Excel文件

**前端處理建議**:
```javascript
// 檢查響應類型並處理文件下載
if (response.headers['content-type'].includes('spreadsheetml.sheet')) {
  const blob = await response.blob();
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = '聊天記錄導出.xlsx';
  link.click();
  window.URL.revokeObjectURL(url);
}
```

## 🔧 職業字段統一說明

### 重要變更
根據《職業字段統一修復文檔》，後端已統一處理職業字段：

**建議前端使用**:
- ✅ `position`: 統一的職業字段
- ❌ `occupation`: 舊字段（仍支持但不推薦）

**響應格式統一**:
所有用戶相關API響應中，職業信息都會出現在根級 `position` 字段中，而非嵌套的 `profile.position`。

## 🚨 錯誤處理

### 常見錯誤碼
- `AUTH_REQUIRED`: 需要認證
- `INVALID_SESSION`: 無效會話ID
- `INSUFFICIENT_QUERIES`: 諮詢次數不足
- `VALIDATION_ERROR`: 參數驗證錯誤
- `PERMISSION_DENIED`: 權限不足

### 錯誤響應示例
```javascript
{
  "success": false,
  "message": "諮詢次數不足",
  "error": {
    "code": "INSUFFICIENT_QUERIES",
    "details": "您的剩餘諮詢次數為0，請聯繫管理員增加次數"
  }
}
```

## 🎯 前端對接指南

### 1. 認證流程
1. 用戶登入後獲取JWT token
2. 將token存儲在localStorage或sessionStorage
3. 每次API請求都在Header中包含token

### 2. 會話管理建議
```javascript
// 建議的會話狀態管理
const chatState = {
  currentSession: null,
  sessionList: [],
  messages: []
};

// 選擇會話時更新狀態
function selectSession(session) {
  chatState.currentSession = session;
  loadMessages(session.sessionId);
}
```

### 3. AI回復顯示處理
```javascript
// 處理AI回復的法條引用
function renderAIResponse(aiResponse) {
  const content = aiResponse.content;
  const references = aiResponse.references;
  
  // 顯示主要內容
  renderContent(content);
  
  // 顯示法條引用
  if (references && references.length > 0) {
    renderReferences(references);
  }
}
```

### 4. 文件導出處理
```javascript
// 導出文件的通用處理函數
async function handleExport(exportData) {
  const response = await fetch('/admin/chat/export', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(exportData)
  });
  
  if (response.headers.get('content-type').includes('spreadsheetml.sheet')) {
    // 處理Excel文件下載
    const blob = await response.blob();
    downloadFile(blob, 'chat_export.xlsx');
  } else {
    // 處理JSON響應
    const result = await response.json();
    handleApiResponse(result);
  }
}
```

## 🚀 測試建議

### 真實數據測試
**重要提醒**: 請直接使用生產環境的真實數據進行測試，不提供Mock數據。

**測試環境**:
- API基礎URL: `https://wrrfvodsaofk.sealosgzg.site/api/v1`
- 測試頁面: `https://wrrfvodsaofk.sealosgzg.site/test-api`

**測試賬號**:
```javascript
// 超級管理員
{
  username: "admin",
  email: "test@ailaborlaw.com", 
  password: "Test1234"
}

// 普通管理員
{
  username: "newadmin",
  email: "newadmin@ailaborlaw.com",
  password: "Admin1234"  
}
```

### 測試流程建議
1. **認證測試**: 先測試管理員登入
2. **會話測試**: 創建會話→發送消息→獲取AI回復
3. **管理功能測試**: 會話監控→統計數據→導出功能
4. **錯誤場景測試**: 無效ID、空消息、權限不足等

## 📞 技術支持

如在對接過程中遇到問題，請提供：
1. 具體的API端點和請求參數
2. 完整的錯誤響應
3. 瀏覽器網絡面板的請求詳情

---

**文檔版本**: v1.0  
**最後更新**: 2025年5月25日  
**維護人員**: AI助手  
**測試狀態**: 所有API已通過真實環境測試 ✅ 