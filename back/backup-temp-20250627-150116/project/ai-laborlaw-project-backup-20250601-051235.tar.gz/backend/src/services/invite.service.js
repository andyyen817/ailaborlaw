import mongoose from 'mongoose';
import User from '../models/user.model.js';
import InviteRecord from '../models/invite-record.model.js';
import QueryRecord from '../models/query-record.model.js';
import SystemSetting from '../models/system-setting.model.js';
import { AppError, errorUtils } from '../utils/error.js';
import logger from '../utils/logger.js';

/**
 * 邀请服务类
 * 处理用户邀请相关的所有业务逻辑
 */
class InviteService {
  
  /**
   * 生成唯一邀请码
   * @param {number} length - 邀请码长度
   * @returns {Promise<string>} 唯一邀请码
   */
  static async generateUniqueInviteCode(length = 8) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let attempts = 0;
    const maxAttempts = 50;
    
    while (attempts < maxAttempts) {
      let code = '';
      for (let i = 0; i < length; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      
      // 检查是否已存在
      const existing = await User.findOne({ myInviteCode: code });
      if (!existing) {
        return code;
      }
      
      attempts++;
    }
    
    throw new AppError('无法生成唯一邀请码，请稍后重试', 500);
  }
  
  /**
   * 验证邀请码
   * @param {string} inviteCode - 邀请码
   * @returns {Promise<Object>} 验证结果
   */
  static async validateInviteCode(inviteCode) {
    try {
      if (!inviteCode || typeof inviteCode !== 'string') {
        return {
          valid: false,
          message: '邀请码格式无效'
        };
      }
      
      const trimmedCode = inviteCode.trim().toUpperCase();
      if (trimmedCode.length < 4 || trimmedCode.length > 20) {
        return {
          valid: false,
          message: '邀请码长度无效'
        };
      }
      
      // 查找邀请人
      const inviter = await User.findOne({ 
        myInviteCode: trimmedCode,
        status: 'active'
      });
      
      if (!inviter) {
        return {
          valid: false,
          message: '邀请码不存在或已失效'
        };
      }
      
      // 检查邀请系统是否启用
      const inviteEnabled = await SystemSetting.getValue('ENABLE_INVITE_SYSTEM', true);
      if (!inviteEnabled) {
        return {
          valid: false,
          message: '邀请系统暂时关闭'
        };
      }
      
      return {
        valid: true,
        inviter: {
          id: inviter._id,
          name: inviter.name,
          email: inviter.email
        },
        message: '邀请码有效'
      };
    } catch (error) {
      logger.error('验证邀请码时发生错误:', error);
      return {
        valid: false,
        message: '验证邀请码时发生错误'
      };
    }
  }
  
  /**
   * 处理邀请注册
   * @param {string} newUserId - 新用户ID
   * @param {string} inviteCode - 邀请码
   * @returns {Promise<Object>} 处理结果
   */
  static async processInviteRegistration(newUserId, inviteCode) {
    const session = await mongoose.startSession();
    session.startTransaction();
    
    try {
      // 验证邀请码
      const validation = await this.validateInviteCode(inviteCode);
      if (!validation.valid) {
        throw new AppError(validation.message, 400);
      }
      
      const inviterId = validation.inviter.id;
      
      // 检查是否已经处理过这个邀请
      const existingRecord = await InviteRecord.findOne({
        inviterId,
        inviteeId: newUserId
      });
      
      if (existingRecord) {
        await session.abortTransaction();
        return {
          success: false,
          message: '此邀请关系已存在',
          alreadyProcessed: true
        };
      }
      
      // 获取系统设置
      const [inviterBonus, inviteeBonus] = await Promise.all([
        SystemSetting.getValue('INVITE_BONUS_QUERIES', 10),
        SystemSetting.getValue('INVITEE_BONUS_QUERIES', 10)
      ]);
      
      // 更新被邀请人信息
      const invitee = await User.findByIdAndUpdate(
        newUserId,
        {
          invitedBy: inviterId,
          inviteCode: inviteCode.toUpperCase(),
          $inc: { remainingQueries: inviteeBonus }
        },
        { 
          session, 
          new: true,
          runValidators: true
        }
      );
      
      if (!invitee) {
        throw new AppError('被邀请用户不存在', 404);
      }
      
      // 更新邀请人信息
      const inviter = await User.findByIdAndUpdate(
        inviterId,
        {
          $inc: { 
            invitedCount: 1,
            remainingQueries: inviterBonus
          }
        },
        { 
          session, 
          new: true,
          runValidators: true
        }
      );
      
      if (!inviter) {
        throw new AppError('邀请人不存在', 404);
      }
      
      // 创建邀请记录
      const inviteRecord = await InviteRecord.createInviteRecord(
        inviterId,
        newUserId,
        inviteCode,
        inviterBonus,
        inviteeBonus
      );
      
      await inviteRecord.save({ session });
      
      // 记录奖励日志
      await Promise.all([
        QueryRecord.recordInviteBonus(
          newUserId,
          inviteeBonus,
          invitee.remainingQueries,
          inviteRecord._id
        ),
        QueryRecord.recordInviteBonus(
          inviterId,
          inviterBonus,
          inviter.remainingQueries,
          inviteRecord._id
        )
      ]);
      
      await session.commitTransaction();
      
      logger.info(`邀请注册处理成功: 邀请人 ${inviterId}, 被邀请人 ${newUserId}`);
      
      return {
        success: true,
        message: '邀请注册处理成功',
        data: {
          inviteRecord: inviteRecord._id,
          inviterBonus,
          inviteeBonus,
          inviteeRemainingQueries: invitee.remainingQueries,
          inviterRemainingQueries: inviter.remainingQueries
        }
      };
      
    } catch (error) {
      await session.abortTransaction();
      logger.error('处理邀请注册时发生错误:', error);
      
      if (error instanceof AppError) {
        throw error;
      }
      
      throw new AppError('处理邀请注册时发生内部错误', 500);
    } finally {
      session.endSession();
    }
  }
  
  /**
   * 获取用户邀请统计
   * @param {string} userId - 用户ID
   * @returns {Promise<Object>} 邀请统计信息
   */
  static async getUserInviteStats(userId) {
    try {
      const user = await User.findById(userId);
      if (!user) {
        throw new AppError('用户不存在', 404);
      }
      
      // 获取邀请记录统计
      const inviteStats = await InviteRecord.getInviteStats(userId);
      
      // 获取最近的邀请记录
      const recentInvites = await InviteRecord.find({ inviterId: userId })
        .populate('inviteeId', 'name email registrationDate')
        .sort({ createdAt: -1 })
        .limit(10);
      
      // 统计数据处理
      let totalInvites = 0;
      let successfulInvites = 0;
      let pendingInvites = 0;
      let totalBonusEarned = 0;
      
      inviteStats.forEach(stat => {
        totalInvites += stat.count;
        if (stat._id === 'completed') {
          successfulInvites = stat.count;
          totalBonusEarned = stat.totalInviterBonus;
        } else if (stat._id === 'pending') {
          pendingInvites = stat.count;
        }
      });
      
      return {
        success: true,
        data: {
          myInviteCode: user.myInviteCode,
          totalInvites,
          successfulInvites,
          pendingInvites,
          totalBonusEarned,
          conversionRate: totalInvites > 0 ? (successfulInvites / totalInvites * 100).toFixed(2) : 0,
          recentInvites: recentInvites.map(record => ({
            inviteeId: record.inviteeId._id,
            inviteeName: record.inviteeId.name,
            inviteeEmail: record.inviteeId.email,
            inviteDate: record.createdAt,
            completedDate: record.completedAt,
            status: record.status,
            bonusEarned: record.inviterBonus
          }))
        }
      };
      
    } catch (error) {
      logger.error('获取用户邀请统计时发生错误:', error);
      
      if (error instanceof AppError) {
        throw error;
      }
      
      throw new AppError('获取邀请统计时发生内部错误', 500);
    }
  }
  
  /**
   * 获取邀请排行榜
   * @param {number} limit - 返回数量限制
   * @param {Date} startDate - 开始日期
   * @param {Date} endDate - 结束日期
   * @returns {Promise<Object>} 排行榜数据
   */
  static async getInviteLeaderboard(limit = 10, startDate = null, endDate = null) {
    try {
      const topInviters = await InviteRecord.getTopInviters(limit, startDate, endDate);
      
      return {
        success: true,
        data: {
          topInviters,
          period: {
            startDate,
            endDate,
            limit
          }
        }
      };
      
    } catch (error) {
      logger.error('获取邀请排行榜时发生错误:', error);
      throw new AppError('获取邀请排行榜时发生内部错误', 500);
    }
  }
  
  /**
   * 获取邀请系统统计
   * @param {Date} startDate - 开始日期
   * @param {Date} endDate - 结束日期
   * @returns {Promise<Object>} 系统统计数据
   */
  static async getInviteSystemStats(startDate = null, endDate = null) {
    try {
      const matchCondition = {};
      
      if (startDate || endDate) {
        matchCondition.createdAt = {};
        if (startDate) matchCondition.createdAt.$gte = startDate;
        if (endDate) matchCondition.createdAt.$lte = endDate;
      }
      
      // 获取基础统计
      const baseStats = await InviteRecord.aggregate([
        { $match: matchCondition },
        {
          $group: {
            _id: '$status',
            count: { $sum: 1 },
            totalInviterBonus: { $sum: '$inviterBonus' },
            totalInviteeBonus: { $sum: '$inviteeBonus' }
          }
        }
      ]);
      
      // 获取每日趋势
      const dailyTrends = await InviteRecord.aggregate([
        { $match: matchCondition },
        {
          $group: {
            _id: {
              date: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
              status: '$status'
            },
            count: { $sum: 1 },
            bonusDistributed: { $sum: { $add: ['$inviterBonus', '$inviteeBonus'] } }
          }
        },
        { $sort: { '_id.date': 1 } }
      ]);
      
      // 处理统计数据
      let totalInvites = 0;
      let successfulInvites = 0;
      let totalBonusDistributed = 0;
      
      baseStats.forEach(stat => {
        totalInvites += stat.count;
        if (stat._id === 'completed') {
          successfulInvites = stat.count;
          totalBonusDistributed = stat.totalInviterBonus + stat.totalInviteeBonus;
        }
      });
      
      const conversionRate = totalInvites > 0 ? (successfulInvites / totalInvites * 100).toFixed(2) : 0;
      
      return {
        success: true,
        data: {
          summary: {
            totalInvites,
            successfulInvites,
            conversionRate: parseFloat(conversionRate),
            totalBonusDistributed
          },
          trends: {
            daily: dailyTrends
          },
          statusBreakdown: baseStats
        }
      };
      
    } catch (error) {
      logger.error('获取邀请系统统计时发生错误:', error);
      throw new AppError('获取邀请系统统计时发生内部错误', 500);
    }
  }
  
  /**
   * 发放注册奖励
   * @param {string} userId - 用户ID
   * @returns {Promise<Object>} 发放结果
   */
  static async grantRegistrationBonus(userId) {
    const session = await mongoose.startSession();
    session.startTransaction();
    
    try {
      // 检查用户是否已获得注册奖励
      const existingBonus = await QueryRecord.findOne({
        userId,
        action: 'registration_bonus'
      });
      
      if (existingBonus) {
        await session.abortTransaction();
        return {
          success: false,
          message: '注册奖励已发放',
          alreadyGranted: true
        };
      }
      
      // 获取注册奖励设置
      const bonusAmount = await SystemSetting.getValue('REGISTRATION_BONUS_QUERIES', 10);
      
      // 更新用户咨询次数
      const user = await User.findByIdAndUpdate(
        userId,
        {
          $inc: { remainingQueries: bonusAmount }
        },
        { 
          session, 
          new: true,
          runValidators: true
        }
      );
      
      if (!user) {
        throw new AppError('用户不存在', 404);
      }
      
      // 记录奖励日志
      await QueryRecord.recordRegistrationBonus(
        userId,
        bonusAmount,
        user.remainingQueries
      );
      
      await session.commitTransaction();
      
      logger.info(`注册奖励发放成功: 用户 ${userId}, 奖励 ${bonusAmount} 次`);
      
      return {
        success: true,
        message: '注册奖励发放成功',
        data: {
          bonusAmount,
          remainingQueries: user.remainingQueries
        }
      };
      
    } catch (error) {
      await session.abortTransaction();
      logger.error('发放注册奖励时发生错误:', error);
      
      if (error instanceof AppError) {
        throw error;
      }
      
      throw new AppError('发放注册奖励时发生内部错误', 500);
    } finally {
      session.endSession();
    }
  }
}

export default InviteService; 