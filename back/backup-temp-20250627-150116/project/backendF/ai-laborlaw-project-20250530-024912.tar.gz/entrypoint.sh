#!/bin/bash
cd /home/devbox/project
node app.js