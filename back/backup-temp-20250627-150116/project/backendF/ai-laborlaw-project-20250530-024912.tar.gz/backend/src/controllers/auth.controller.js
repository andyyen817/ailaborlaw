import User from '../models/user.model.js';
import { generateAccessToken } from '../utils/jwt.js';
import logger from '../utils/logger.js';
// 假设会有 express-validator 的结果处理函数
// import { validationResult } from 'express-validator';

/**
 * 用戶註冊
 * @param {Object} req - Express 請求對象
 * @param {Object} res - Express 響應對象
 */
export const registerUser = async (req, res) => {
  // 注意：輸入驗證現在由 express-validator 中間件處理

  const { 
    name,                 // 暱稱
    email,                // 電子郵箱
    password,             // 密碼
    userType,             // 用戶類型
    industry,             // 行業
    position,             // 職位/職業 (新字段)
    occupation,           // 職位/職業 (舊字段，向後兼容)
    inviteCode,           // 邀請碼
    profile,              // 完整的用戶檔案對象
    companyName           // 公司名稱
  } = req.body;

  try {
    // 1. 檢查郵箱是否已存在
    const existingUser = await User.findOne({ email: email.toLowerCase() });
    if (existingUser) {
      return res.status(409).json({ // 409 Conflict
        success: false,
        message: '此電子郵箱已被註冊',
        error: { code: 'EMAIL_ALREADY_EXISTS', details: `Email ${email} is already registered.` }
      });
    }

    // 2. 創建新用戶 (密碼哈希將在 User Model 的 pre-save hook 中自動完成)
    // 處理用戶類型和基本資料
    const userData = {
      name,
      email: email.toLowerCase(),
      password,
      userType: userType || 'employee',
      status: 'active', // 此處根據需求設置為 active 而非 pending
    };

    // 處理可選字段
    if (profile) {
      userData.profile = profile;
    } else {
      // 如果沒有提供完整profile對象，創建一個
      userData.profile = {};
      // 處理行業字段
      if (industry) userData.profile.industry = industry;
      
      // 處理職位/職業字段（支持向後兼容）
      const finalPosition = position || occupation; // 優先使用 position，fallback 到 occupation
      if (finalPosition) userData.profile.position = finalPosition;
    }

    // 處理其他可選字段
    if (companyName) userData.companyName = companyName;
    if (inviteCode) userData.inviteCode = inviteCode;

    const newUser = new User(userData);
    await newUser.save();

    // 3. 生成 JWT
    const tokenPayload = {
      userId: newUser._id.toString(),
      userType: newUser.userType
    };
    const token = generateAccessToken(tokenPayload);

    if (!token) {
      logger.error(`JWT 生成失敗，用戶: ${newUser._id}`);
      return res.status(500).json({
        success: false,
        message: '用戶註冊成功，但登入憑證生成失敗，請稍後嘗試登入',
        error: { code: 'TOKEN_GENERATION_FAILED' }
      });
    }

    // 4. 準備響應數據 (不包含密碼等敏感信息)
    const userResponse = {
      id: newUser._id.toString(),
      name: newUser.name,
      email: newUser.email,
      userType: newUser.userType,
      status: newUser.status,
      remainingQueries: newUser.remainingQueries,
      // 統一字段命名，將嵌套的profile字段映射到根級字段
      industry: newUser.profile?.industry || '',
      position: newUser.profile?.position || '',
      phoneNumber: newUser.profile?.phone || '',
      companyName: newUser.profile?.company || '',
      // 保留原有字段以向後兼容
      inviteCode: newUser.inviteCode,
      totalConsultations: newUser.totalConsultations || 0
    };

    return res.status(201).json({ // 201 Created
      success: true,
      message: '用戶註冊成功',
      data: {
        token,
        user: userResponse
      }
    });

  } catch (error) {
    logger.error(`用戶註冊錯誤: ${error.message}`, { email, name, stack: error.stack });
    // 檢查是否是 Mongoose 驗證錯誤
    if (error.name === 'ValidationError') {
      return res.status(400).json({
        success: false,
        message: '用戶註冊資訊驗證失敗',
        error: { code: 'VALIDATION_ERROR', details: error.errors }
      });
    }
    return res.status(500).json({
      success: false,
      message: '伺服器在處理用戶註冊時發生錯誤',
      error: { code: 'INTERNAL_SERVER_ERROR', details: error.message }
    });
  }
};

/**
 * 用戶登入
 * @param {Object} req - Express 請求對象
 * @param {Object} res - Express 響應對象
 */
export const loginUser = async (req, res) => {
  // 注意：輸入驗證現在由 express-validator 中間件處理

  const { email, password } = req.body;

  try {
    // 1. 通過 email 查找用戶
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      return res.status(401).json({ // 401 Unauthorized
        success: false,
        message: '認證失敗：郵箱或密碼錯誤', // 通用錯誤資訊，避免洩露用戶是否存在
        error: { code: 'INVALID_CREDENTIALS', details: 'Incorrect email or password.' }
      });
    }

    // 2. 比較提交的密碼與資料庫中存儲的哈希密碼
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: '認證失敗：郵箱或密碼錯誤',
        error: { code: 'INVALID_CREDENTIALS', details: 'Incorrect email or password.' }
      });
    }

    // 3. 檢查用戶狀態
    if (user.status === 'pending') {
      return res.status(401).json({
        success: false,
        message: '賬戶尚待啟動/驗證，請檢查您的郵箱或聯絡管理員',
        error: { code: 'ACCOUNT_PENDING_VERIFICATION', details: 'Account is pending verification.' }
      });
    }
    if (user.status === 'disabled') {
      return res.status(401).json({
        success: false,
        message: '您的賬戶已被禁用，請聯絡管理員',
        error: { code: 'ACCOUNT_DISABLED', details: 'Account has been disabled.' }
      });
    }
    if (user.status === 'deleted') {
      return res.status(401).json({
        success: false,
        message: '您的賬戶已被刪除，請聯絡管理員',
        error: { code: 'ACCOUNT_DELETED', details: 'Account has been deleted.' }
      });
    }
    if (user.status !== 'active') { // 其他非 active 狀態
        return res.status(401).json({
            success: false,
            message: `賬戶狀態異常 (${user.status})，無法登入`,
            error: { code: 'ACCOUNT_STATUS_NOT_ACTIVE', details: `Account status is '${user.status}'.`}
        });
    }

    // 4. 更新用戶的 lastLogin 字段
    user.lastLogin = new Date();
    await user.save();

    // 5. 生成 JWT
    const tokenPayload = {
      userId: user._id.toString(),
      userType: user.userType
    };
    const token = generateAccessToken(tokenPayload);

    if (!token) {
      logger.error(`JWT 生成失敗，用戶登入: ${user._id}`);
      return res.status(500).json({
        success: false,
        message: '登入成功，但授權憑證生成失敗，請重試',
        error: { code: 'TOKEN_GENERATION_FAILED' }
      });
    }
    
    // 6. 準備響應數據，統一字段命名
    const userResponse = {
      id: user._id.toString(),
      name: user.name,
      email: user.email,
      userType: user.userType,
      status: user.status,
      remainingQueries: user.remainingQueries,
      totalConsultations: user.totalConsultations || 0,
      // 統一字段命名，將嵌套的profile字段映射到根級字段
      industry: user.profile?.industry || '',
      position: user.profile?.position || '',
      phoneNumber: user.profile?.phone || '',
      companyName: user.profile?.company || '',
      // 保留原有字段
      inviteCode: user.inviteCode
    };

    return res.status(200).json({
      success: true,
      message: '登入成功',
      data: {
        token,
        user: userResponse
      }
    });

  } catch (error) {
    logger.error(`用戶登入錯誤: ${error.message}`, { email, stack: error.stack });
    return res.status(500).json({
      success: false,
      message: '伺服器在處理登入請求時發生錯誤',
      error: { code: 'INTERNAL_SERVER_ERROR', details: error.message }
    });
  }
};
