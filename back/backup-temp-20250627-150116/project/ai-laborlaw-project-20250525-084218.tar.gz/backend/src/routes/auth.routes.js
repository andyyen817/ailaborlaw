import express from 'express';
import * as authController from '../controllers/auth.controller.js';
// 導入輸入驗證中間件
import { validateRegistration, validateLogin } from '../validations/auth.validation.js';
import { handleValidationErrors } from '../middlewares/error-handlers.middleware.js';

const router = express.Router();

/**
 * @swagger
 * tags:
 *   name: Authentication
 *   description: User registration and login
 */

/**
 * @swagger
 * /auth/register:
 *   post:
 *     summary: Register a new user
 *     tags: [Authentication]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *               - email
 *               - password
 *             properties:
 *               name:
 *                 type: string
 *                 example: "張三"
 *               email:
 *                 type: string
 *                 format: email
 *                 example: "zhangsan@example.com"
 *               password:
 *                 type: string
 *                 format: password
 *                 minLength: 8
 *                 example: "password123"
 *               profile:
 *                 type: object
 *                 properties:
 *                   industry:
 *                     type: string
 *                     example: "tech"
 *                   position:
 *                     type: string
 *                     example: "employee"
 *     responses:
 *       201:
 *         description: User registered successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/AuthResponse'
 *       400:
 *         description: Invalid input
 *       409:
 *         description: Email already exists
 */
// 路由: POST /api/v1/auth/register
router.post('/register', validateRegistration, handleValidationErrors, authController.registerUser);

/**
 * @swagger
 * /auth/login:
 *   post:
 *     summary: Log in an existing user
 *     tags: [Authentication]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - email
 *               - password
 *             properties:
 *               email:
 *                 type: string
 *                 format: email
 *                 example: "zhangsan@example.com"
 *               password:
 *                 type: string
 *                 format: password
 *                 example: "password123"
 *     responses:
 *       200:
 *         description: Login successful
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/AuthResponse'
 *       400:
 *         description: Invalid input
 *       401:
 *         description: Authentication failed (e.g., incorrect email/password, account inactive)
 */
// 路由: POST /api/v1/auth/login
router.post('/login', validateLogin, handleValidationErrors, authController.loginUser);

export default router;

// Swagger/OpenAPI 组件定义 (通常放在主 app.js 或 swagger配置文件中, 这里为了方便查看)
/**
 * @swagger
 * components:
 *   schemas:
 *     AuthResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *           example: "操作成功"
 *         data:
 *           type: object
 *           properties:
 *             token:
 *               type: string
 *               example: "jwt.token.string"
 *             user:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                   example: "mongodb_object_id"
 *                 name:
 *                   type: string
 *                   example: "張三"
 *                 email:
 *                   type: string
 *                   example: "zhangsan@example.com"
 *                 userType:
 *                   type: string
 *                   example: "employee"
 *                 status:
 *                   type: string
 *                   example: "pending" # For registration response
 *                 remainingQueries:
 *                   type: number
 *                   example: 10 # For registration response
 *   securitySchemes:
 *     bearerAuth:
 *       type: http
 *       scheme: bearer
 *       bearerFormat: JWT
 */
