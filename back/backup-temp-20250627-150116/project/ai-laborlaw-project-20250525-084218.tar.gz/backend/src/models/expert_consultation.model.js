const mongoose = require('mongoose');

/**
 * 专家咨询模型
 * 根据PRD数据库设计实现
 */
const expertConsultationSchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  expert_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Expert',
    default: null
  },
  status: {
    type: String,
    enum: ['pending', 'assigned', 'in_progress', 'completed', 'cancelled'],
    default: 'pending'
  },
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true
  },
  priority: {
    type: String,
    enum: ['normal', 'urgent'],
    default: 'normal'
  },
  contact_method: {
    type: String,
    enum: ['form', 'line'],
    default: 'form'
  },
  attachment_urls: [{
    type: String
  }],
  feedback: {
    rating: {
      type: Number,
      min: 1,
      max: 5,
      default: null
    },
    comment: {
      type: String,
      default: ''
    }
  },
  created_at: {
    type: Date,
    default: Date.now
  },
  updated_at: {
    type: Date,
    default: Date.now
  },
  completed_at: Date
}, {
  timestamps: { 
    createdAt: 'created_at', 
    updatedAt: 'updated_at' 
  }
});

// 索引
expertConsultationSchema.index({ user_id: 1 });
expertConsultationSchema.index({ expert_id: 1 });
expertConsultationSchema.index({ status: 1 });
expertConsultationSchema.index({ created_at: 1 });
expertConsultationSchema.index({ priority: 1 });

// 更新状态的方法
expertConsultationSchema.methods.updateStatus = async function(newStatus) {
  this.status = newStatus;
  
  if (newStatus === 'completed') {
    this.completed_at = new Date();
  }
  
  await this.save();
  return this;
};

// 分配专家的方法
expertConsultationSchema.methods.assignExpert = async function(expertId) {
  this.expert_id = expertId;
  this.status = 'assigned';
  await this.save();
  return this;
};

// 添加反馈的方法
expertConsultationSchema.methods.addFeedback = async function(rating, comment) {
  this.feedback = {
    rating,
    comment: comment || ''
  };
  await this.save();
  return this;
};

module.exports = mongoose.model('ExpertConsultation', expertConsultationSchema); 